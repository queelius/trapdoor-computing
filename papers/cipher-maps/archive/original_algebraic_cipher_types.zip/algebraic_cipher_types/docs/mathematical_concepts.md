/**
@page mathematical_concepts_page Mathematical Concepts

@tableofcontents

@section math_intro Introduction

This document provides the mathematical foundation for the Algebraic Cipher Types library. We present the core concepts in an accessible way, starting from basic algebraic structures and building up to the cipher functor framework.

@section math_algebraic_structures Algebraic Structures

@subsection math_monoid Monoids

A **monoid** is a fundamental algebraic structure consisting of:
- A set S
- A binary operation * : S × S → S
- An identity element e ∈ S

**Properties:**
1. **Closure**: For all a, b ∈ S, a * b ∈ S
2. **Associativity**: For all a, b, c ∈ S, (a * b) * c = a * (b * c)
3. **Identity**: For all a ∈ S, e * a = a * e = a

**Examples in the Library:**
- Integers under addition: (ℤ, +, 0)
- Integers under multiplication: (ℤ, ×, 1)
- Booleans under AND: (𝔹, ∧, true)
- Booleans under OR: (𝔹, ∨, false)

@code{.cpp}
// Monoid laws preserved in encryption
cipher_int32 a(5, key), b(3, key), c(7, key);
cipher_int32 zero(0, key);

// Associativity: (a + b) + c == a + (b + c)
auto left = (a + b) + c;
auto right = a + (b + c);
assert(left.decrypt(key) == right.decrypt(key));

// Identity: a + 0 == a
auto with_identity = a + zero;
assert(with_identity.decrypt(key) == a.decrypt(key));
@endcode

@subsection math_group Groups

A **group** extends a monoid with inverses:
- Everything from monoids
- For each a ∈ S, there exists a⁻¹ such that a * a⁻¹ = a⁻¹ * a = e

**Example:**
- Integers under addition with negation: (ℤ, +, 0, -)

@code{.cpp}
cipher_int32 a(5, key);
auto neg_a = -a;  // Additive inverse
auto result = a + neg_a;
assert(result.decrypt(key) == std::optional<int32_t>(0));
@endcode

@subsection math_ring Rings

A **ring** combines two group-like structures:
- (R, +, 0) is an abelian group
- (R, ×, 1) is a monoid
- Multiplication distributes over addition

**Properties:**
1. **Additive group**: (R, +) with identity 0 and inverses
2. **Multiplicative monoid**: (R, ×) with identity 1
3. **Distributivity**: a × (b + c) = (a × b) + (a × c)

@code{.cpp}
// Ring laws for encrypted integers
cipher_int32 a(2, key), b(3, key), c(4, key);

// Distributivity
auto left_dist = a * (b + c);
auto right_dist = (a * b) + (a * c);
assert(left_dist.decrypt(key) == right_dist.decrypt(key));
@endcode

@subsection math_field Fields

A **field** is a ring where every non-zero element has a multiplicative inverse. While integers don't form a field, rational numbers do. The library could be extended to support field operations.

@section math_category_theory Category Theory Concepts

@subsection math_category Categories

A **category** consists of:
- **Objects**: Types in our case (int, bool, pair<A,B>, etc.)
- **Morphisms**: Functions between types
- **Composition**: Function composition
- **Identity**: Identity function for each type

In our library:
- Objects are C++ types
- Morphisms are functions
- Composition is function composition
- Identity is the identity function

@subsection math_functor Functors

A **functor** F is a mapping between categories that:
1. Maps objects: A → F(A)
2. Maps morphisms: (A → B) → (F(A) → F(B))
3. Preserves identity: F(id_A) = id_F(A)
4. Preserves composition: F(g ∘ f) = F(g) ∘ F(f)

**The Cipher Functor:**

Our `cipher` is a functor from the category of types to the category of encrypted types:

```
Type Category          Cipher Category
     int      ─────→    cipher<int>
      ↓ f                    ↓ cipher_f
     bool     ─────→    cipher<bool>
```

@code{.cpp}
// Functor mapping example
template<typename A, typename B>
cipher<B> fmap(std::function<B(A)> f,
               const cipher<A>& encrypted_a,
               const secret_key& key) {
    auto decrypted = encrypted_a.decrypt(key);
    if (decrypted) {
        B result = f(*decrypted);
        return cipher<B>(result, key);
    }
    return cipher<B>{};  // Invalid cipher
}

// Usage
cipher<int> encrypted_x(10, key);
auto encrypted_squared = fmap<int, int>(
    [](int x) { return x * x; },
    encrypted_x,
    key
);
@endcode

@subsection math_monad Monads

A **monad** extends a functor with:
1. **Unit** (return): A → M(A)
2. **Bind** (>>=): M(A) → (A → M(B)) → M(B)

**Optional as a Monad:**

@code{.cpp}
// Monadic operations on cipher<optional<T>>
template<typename A, typename B>
cipher<std::optional<B>> bind(
    const cipher<std::optional<A>>& ma,
    std::function<cipher<std::optional<B>>(A)> f,
    const secret_key& key
) {
    auto decrypted = ma.decrypt(key);
    if (decrypted && *decrypted) {
        return f(**decrypted);
    }
    return cipher<std::optional<B>>::none(key);
}
@endcode

@section math_homomorphism Homomorphisms

@subsection math_homo_definition Definition

A **homomorphism** is a structure-preserving map between algebraic structures. For a function h: A → B between monoids (A, *_A) and (B, *_B):

h(x *_A y) = h(x) *_B h(y)

@subsection math_homo_encryption Homomorphic Encryption

In our context, encryption E and decryption D form a homomorphic system when:

**Homomorphic Property:**
```
D(E(x) ⊕ E(y)) = x ⊗ y
```

Where:
- ⊗ is the operation in plaintext space
- ⊕ is the corresponding operation in ciphertext space

@code{.cpp}
// Additive homomorphism
cipher_int32 x(10, key), y(20, key);
auto encrypted_sum = x + y;  // Operation in cipher space

auto decrypted_sum = encrypted_sum.decrypt(key);
assert(decrypted_sum == std::optional<int32_t>(30));

// Multiplicative homomorphism
auto encrypted_product = x * y;
auto decrypted_product = encrypted_product.decrypt(key);
assert(decrypted_product == std::optional<int32_t>(200));
@endcode

@subsection math_homo_types Types of Homomorphic Encryption

**1. Partially Homomorphic (PHE)**
- Supports one operation (e.g., only addition OR multiplication)
- Examples: RSA (multiplicative), Paillier (additive)

**2. Somewhat Homomorphic (SWHE)**
- Supports limited operations of both types
- Noise grows with operations

**3. Fully Homomorphic (FHE)**
- Supports arbitrary computations
- Our library approximates FHE for specific types

@section math_cipher_functor The Cipher Functor Framework

@subsection math_cf_definition Formal Definition

Given a monoid (S, *, e), the cipher functor c_A creates:

**c_A(S) = { encrypt(s, k, r) | s ∈ S, k ∈ K, r ∈ R }**

Where:
- S is the plaintext space
- K is the key space
- R is the randomness space (for semantic security)
- A ⊆ S is the encoding set

@subsection math_cf_properties Properties

**1. Functoriality:**
```
cipher(f: A → B) : cipher<A> → cipher<B>
```

**2. Homomorphic Operations:**
```
decrypt(cipher_op(E(a), E(b))) = plain_op(a, b)
```

**3. Preservation of Laws:**
- Associativity preserved
- Commutativity preserved (when applicable)
- Identity elements preserved
- Distributivity preserved (for rings)

@subsection math_cf_encoding Encoding Theory

The encoding function uses multiple representations:

**k-th Representation:**
For element a ∈ A, the k-th representation is:
```
repr_k(a) = base_encoding(a) ⊕ random_mask(k, a)
```

This provides:
- **Semantic security**: Same plaintext → different ciphertexts
- **Correctness**: All representations decode to same value

@code{.cpp}
encoding_config config;
config.use_randomization = true;

// Same value, different ciphertexts
cipher_int32 x1(42, key, config);
cipher_int32 x2(42, key, config);

// Different ciphertexts (with high probability)
// But same decryption
assert(x1.decrypt(key) == x2.decrypt(key));
@endcode

@section math_products Product and Sum Types

@subsection math_prod_category Categorical Products

The **categorical product** A × B satisfies:
- Projections: π₁: A × B → A and π₂: A × B → B
- Universal property: For any f: C → A and g: C → B, there exists unique h: C → A × B

**In the Library:**

@code{.cpp}
// Product type encryption preserves structure
using point = std::pair<int32_t, int32_t>;
cipher<point> encrypted_point(std::make_pair(3, 4), key);

// Projections work on encrypted data
auto encrypted_x = encrypted_point.first();   // cipher<int32_t>
auto encrypted_y = encrypted_point.second();  // cipher<int32_t>

// Can reconstruct from projections
assert(encrypted_x.decrypt(key) == std::optional<int32_t>(3));
assert(encrypted_y.decrypt(key) == std::optional<int32_t>(4));
@endcode

@subsection math_sum_category Categorical Sums (Coproducts)

The **categorical sum** A + B satisfies:
- Injections: ι₁: A → A + B and ι₂: B → A + B
- Universal property: For any f: A → C and g: B → C, there exists unique h: A + B → C

**Either Type:**

@code{.cpp}
using result = either<int32_t, std::string>;

// Inject left
auto success = cipher<result>::from_left(42, key);

// Inject right
auto error = cipher<result>::from_right("error", key);

// Pattern matching (conceptually)
auto process = [](const cipher<result>& r) -> cipher<int32_t> {
    // Process without revealing which branch
    return r.match(
        [](int32_t val) { return val; },
        [](const std::string&) { return 0; }
    );
};
@endcode

@section math_security Security Properties

@subsection math_sec_semantic Semantic Security

**IND-CPA Security:**

An encryption scheme is IND-CPA secure if:
For any polynomial-time adversary A, the advantage:

```
|Pr[A(E(m₀)) = 0] - Pr[A(E(m₁)) = 1]| ≤ negligible(λ)
```

Where λ is the security parameter.

**Implementation:**
- Randomized encoding ensures different ciphertexts
- Adversary cannot distinguish encryptions

@subsection math_sec_perfect Perfect Secrecy

While not achieving perfect secrecy (would require |K| ≥ |M|), the library provides:
- **Computational security**: Breaking requires infeasible computation
- **Statistical hiding**: Ciphertext distributions are statistically close

@subsection math_sec_malleability Malleability and Authentication

Homomorphic encryption is inherently malleable. We add authentication:

**Authenticated Encryption:**
```
E'(m) = (E(m), MAC(E(m)))
```

This detects:
- Unauthorized modifications
- Ciphertext substitution
- Replay attacks

@section math_complexity Complexity Analysis

@subsection math_comp_time Time Complexity

| Operation | Plaintext | Ciphertext | Overhead |
|-----------|-----------|------------|----------|
| Addition | O(1) | O(n) | O(n) |
| Multiplication | O(1) | O(n²) or O(n log n) | O(n²) |
| Comparison | O(1) | O(n log n) | O(n log n) |
| Encryption | - | O(n) | O(n) |
| Decryption | - | O(n) | O(n) |

Where n is the ciphertext size (proportional to security parameter).

@subsection math_comp_space Space Complexity

**Ciphertext Expansion:**
```
|cipher(m)| = |m| × expansion_factor(λ, ε)
```

Where:
- λ = security parameter
- ε = false positive rate
- expansion_factor ≈ O(λ/log(1/ε))

Typical expansion: 10-100x for 128-bit security

@section math_correctness Correctness Proofs

@subsection math_proof_homomorphism Homomorphic Property Proof

**Theorem:** For monoid (M, *, e), the cipher functor preserves the operation:

**Proof Sketch:**
1. Let a, b ∈ M
2. E(a) and E(b) are their encryptions
3. Define cipher_* such that D(E(a) cipher_* E(b)) = a * b
4. By construction of cipher_*, this holds
5. Associativity: Follows from associativity of *
6. Identity: E(e) acts as identity in cipher space

@subsection math_proof_functor Functor Laws Proof

**Identity Law:** cipher(id) = id

**Proof:**
```
cipher(id)(E(x)) = E(id(x)) = E(x) = id(E(x))
```

**Composition Law:** cipher(g ∘ f) = cipher(g) ∘ cipher(f)

**Proof:**
```
cipher(g ∘ f)(E(x))
  = E((g ∘ f)(D(E(x))))
  = E(g(f(D(E(x)))))
  = cipher(g)(E(f(D(E(x)))))
  = cipher(g)(cipher(f)(E(x)))
  = (cipher(g) ∘ cipher(f))(E(x))
```

@section math_extensions Extensions and Generalizations

@subsection math_ext_multiparty Multi-Party Computation

Extend to multiple parties with different keys:

```
E_shared(m) = E_k1(E_k2(...E_kn(m)...))
```

Requires threshold decryption or secret sharing.

@subsection math_ext_zkp Zero-Knowledge Proofs

Prove properties without revealing values:

```
Prove: E(x) encrypts value satisfying property P
Without revealing: x itself
```

Applications:
- Range proofs
- Equality proofs
- Membership proofs

@subsection math_ext_differential Differential Privacy

Combine with differential privacy:

```
E(query(data) + noise)
```

Provides:
- Privacy against statistical inference
- Utility through homomorphic aggregation

@section math_conclusion Conclusion

The mathematical foundation of the Algebraic Cipher Types library rests on:

1. **Algebraic Structures**: Preserving monoid, group, and ring properties
2. **Category Theory**: Functorial framework ensuring composability
3. **Homomorphism**: Structure-preserving encryption operations
4. **Security Theory**: Semantic security and authentication

This mathematical rigor ensures:
- **Correctness**: Operations behave as expected
- **Composability**: Complex types from simple ones
- **Security**: Provable security properties
- **Extensibility**: Framework accommodates new types

The cipher functor provides an elegant abstraction that unifies encryption with algebraic computation, enabling practical privacy-preserving applications while maintaining mathematical soundness.

*/