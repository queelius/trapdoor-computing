# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Repository Overview

This repository implements **Algebraic Cipher Types** - a Python library providing a functorial framework for secure computation through homomorphic operations on encrypted algebraic structures. The library is based on category theory and algebraic structures, enabling type-safe privacy-preserving computation.

## Quick Reference

```bash
# Install and test (from algebraic_cipher directory)
cd algebraic_cipher
pip install -e ".[dev]"
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=algebraic_cipher --cov-report=term-missing

# Type checking
mypy src/algebraic_cipher/

# Build paper
cd paper && pdflatex algebraic_cipher_types.tex && bibtex algebraic_cipher_types && pdflatex algebraic_cipher_types.tex
```

## Project Structure

```
algebraic_cipher_types/
├── algebraic_cipher/           # Python package
│   ├── pyproject.toml          # Package configuration
│   ├── README.md               # Package documentation
│   ├── src/algebraic_cipher/
│   │   ├── __init__.py         # Public API exports
│   │   ├── core/               # Key, config, protocols
│   │   │   ├── key.py          # SecretKey (frozen dataclass)
│   │   │   ├── config.py       # EncodingConfig
│   │   │   ├── cipher.py       # Base Cipher[T] class
│   │   │   └── protocols.py    # CipherType, Functor, Monad protocols
│   │   ├── types/              # Cipher types
│   │   │   ├── unit.py         # Unit singleton + CipherUnit
│   │   │   ├── boolean.py      # CipherBool with AND/OR/NOT/XOR
│   │   │   ├── integer.py      # CipherInteger with ring operations
│   │   │   ├── product.py      # CipherPair, CipherTuple
│   │   │   └── sum.py          # Either, CipherEither, CipherOptional
│   │   └── functions/          # Cipher functions
│   │       ├── domain.py       # Domain class
│   │       ├── cipher_function.py  # CipherFunction[X,Y]
│   │       ├── impl.py         # Two-stage algorithm
│   │       └── combinators.py  # identity, compose, product, curry
│   └── tests/                  # Test suite
│       ├── test_core/          # Core type tests
│       ├── test_types/         # Type-specific tests
│       ├── test_functions/     # Function tests
│       └── test_properties/    # Property-based tests (hypothesis)
├── docs/                       # Documentation
│   ├── algebraic_cipher_types.pdf  # Mathematical paper
│   ├── mathematical_concepts.md
│   └── TDD_IMPLEMENTATION_GUIDE.md
└── paper/                      # LaTeX source for paper
```

## Architecture Overview

### Core Mathematical Framework

The library implements the **cipher functor** which lifts a monoid `(S, *, e)` to an encrypted monoid `c_A(S, *, e)`:

- **Encoding**: `encode: S × ℕ → c_A(S)` maps elements to their k-th representation
- **Decoding**: `decode: c_A(S) → S` recovers plaintext
- **Homomorphic Property**: `decode(op(encode(a), encode(b))) = op(a, b)`

This preserves algebraic structure while maintaining encryption.

### Type Hierarchy

1. **Core Types** (`types/`):
   - `Unit` - Single-value type (terminal object)
   - `CipherBool` - Boolean with homomorphic AND, OR, NOT, XOR
   - `CipherInteger` - Integers with ring operations (+, -, *, //, %, comparisons)

2. **Product Types** (`types/product.py`):
   - `CipherPair[A,B]` - Encrypted pairs with component access
   - `CipherTuple` - Encrypted tuples with element operations
   - Operations: `first()`, `second()`, `swap()`, `bimap()`

3. **Sum Types** (`types/sum.py`):
   - `Either[L,R]` - Disjoint union (tagged union)
   - `CipherEither[L,R]` - Encrypted Either with pattern matching
   - `CipherOptional[T]` - Maybe monad with `fmap()` and `bind()`

4. **Cipher Functions** (`functions/`):
   - `CipherFunction[X, Y]` - Functions on encrypted values
   - Two-stage algorithm: domain partitioning + seed finding
   - Function combinators: `compose`, `product`, `curry`, `fanout`

### Key Design Patterns

**Latent-Observable Duality**: Every cipher type maintains:
- **Latent layer**: True plaintext values (hidden)
- **Observable layer**: Encrypted representations (visible)
- **Inference problem**: Recovering latent from observable

**Type Safety via Protocols**:
- `CipherType` - Types that support encryption/decryption
- `Functor` - Types with `fmap()` operation
- `Monad` - Types with `bind()` operation
- Frozen dataclasses with `__slots__` for SecretKey

**Key Management**:
```python
from algebraic_cipher import SecretKey

key = SecretKey("my-secret-key")
derived = key.derive_subkey("encryption")  # Derive subkeys
generated = SecretKey.generate()  # Generate random key
```

Keys use constant-time comparison via `secrets.compare_digest`. Wrong keys return `None`.

### Two-Stage Cipher Function Construction

The `CipherFunction` implementation uses a novel two-stage algorithm:

**Stage 1 - Domain Partitioning**:
- Hash domain elements into bins: `h₁: X → [m]`
- Bin count `m` selected via heuristics
- Creates equivalence classes for efficient lookup

**Stage 2 - Seed Finding**:
- For each bin `i`, find seed `σᵢ` such that:
  `∀x ∈ bin_i: decode(h₂(x || σᵢ)) = f(x)`
- Uses random search with fallback strategies
- Enables oblivious function evaluation

## Running Tests

```bash
cd algebraic_cipher

# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=algebraic_cipher --cov-report=term-missing

# Run property-based tests only
pytest tests/test_properties/ -v

# Run specific test file
pytest tests/test_types/test_integer.py -v

# Run tests matching pattern
pytest tests/ -k "homomorphic"
```

## Type Checking

```bash
cd algebraic_cipher
mypy src/algebraic_cipher/
```

## Common Development Patterns

### Adding a New Cipher Type

1. **Create module** (`src/algebraic_cipher/types/new_type.py`):
   ```python
   @dataclass(slots=True)
   class CipherNewType:
       _value: T | None = field(default=None, repr=False)
       _key_hash: str = field(default="", repr=False)

       @classmethod
       def encrypt(cls, value: T, key: SecretKey) -> "CipherNewType":
           ...

       def decrypt(self, key: SecretKey) -> T | None:
           ...
   ```

2. **Add tests** (`tests/test_types/test_new_type.py`):
   - Unit tests for core operations
   - Property-based tests for algebraic laws
   - Homomorphic property verification

3. **Export in `__init__.py`**:
   ```python
   from algebraic_cipher.types.new_type import CipherNewType
   ```

### Extending Homomorphic Operations

To add operation `⊕` to a cipher type:

1. Implement the operation:
   ```python
   def __add__(self, other: "CipherInteger") -> "CipherInteger":
       self._check_compatible(other)
       if self._value is None or other._value is None:
           return CipherInteger()
       return self._make_result(self._value + other._value)
   ```

2. **Verify homomorphic property** in tests:
   ```python
   def test_addition_homomorphic(self):
       result = (a + b).decrypt(key)
       assert result == a.decrypt(key) + b.decrypt(key)
   ```

3. **Verify algebraic laws** if applicable:
   ```python
   @given(st.integers(), st.integers(), st.integers())
   def test_addition_associative(self, x, y, z):
       # (x + y) + z == x + (y + z)
       ...
   ```

### Working with Product Types

```python
from algebraic_cipher import CipherPair, SecretKey

key = SecretKey("key")
pair = CipherPair.encrypt((42, True), key)

# Access components
first = pair.first()   # CipherInteger
second = pair.second() # CipherBool

# Transform
swapped = pair.swap()  # CipherPair[bool, int]
mapped = pair.bimap(lambda x: x * 2, lambda b: not b)
```

### Working with Sum Types

```python
from algebraic_cipher import CipherOptional, SecretKey

key = SecretKey("key")
opt = CipherOptional.some(42, key)

# Functor operations
doubled = opt.fmap(lambda x: x * 2)

# Monad operations
result = opt.bind(lambda x: CipherOptional.some(x + 1, key) if x > 0 else CipherOptional.none(key))

# Pattern matching
value = opt.get_or_else(0)
```

## Testing Philosophy

Tests follow **TDD principles** focusing on:
- **Behavior over implementation**: Tests verify contracts, not internals
- **Property-based testing**: Verify algebraic laws using Hypothesis
- **Homomorphic correctness**: `decrypt(op(encrypt(a), encrypt(b))) == op(a, b)`
- **Mathematical rigor**: Ring laws, Boolean algebra, functor/monad laws

Property-based tests in `tests/test_properties/`:
- `test_algebraic_laws.py` - Boolean algebra, integer ring laws
- `test_functor_laws.py` - Functor identity/composition, monad laws
- `test_homomorphism.py` - Homomorphic property for all operations

## Related Repositories

This project is part of a research ecosystem:

- **`bernoulli_data_type/`**: Probabilistic data structures with controlled error rates
- **`bernoulli-types/`**: Academic papers on Bernoulli types and oblivious computing

These share the **latent/observed duality** framework and **hash-based construction** techniques.

## Documentation Resources

- **Mathematical Paper**: `docs/algebraic_cipher_types.pdf` - Full theoretical framework
- **Mathematical Concepts**: `docs/mathematical_concepts.md` - Key concepts explained
- **TDD Guide**: `docs/TDD_IMPLEMENTATION_GUIDE.md` - Development methodology

## Code Style

- Python 3.10+ features (type hints, dataclasses, match statements)
- Prefer frozen dataclasses with `__slots__`
- Use `secrets` module for cryptographic operations
- Follow PEP 8 style guidelines
