"""Pytest configuration and fixtures for algebraic_cipher tests."""

import pytest
from algebraic_cipher.core.key import SecretKey


@pytest.fixture
def test_key() -> SecretKey:
    """Provide a test secret key."""
    return SecretKey("test-secret-key-for-testing-only")


@pytest.fixture
def alt_key() -> SecretKey:
    """Provide an alternative test key for wrong-key tests."""
    return SecretKey("alternative-secret-key-wrong")


@pytest.fixture
def random_key() -> SecretKey:
    """Provide a randomly generated key."""
    return SecretKey.generate()
