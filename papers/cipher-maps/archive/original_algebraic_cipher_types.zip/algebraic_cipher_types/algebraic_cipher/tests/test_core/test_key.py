"""Tests for SecretKey."""

import pytest
from algebraic_cipher.core.key import SecretKey


class TestSecretKey:
    """Tests for SecretKey class."""

    def test_creation(self) -> None:
        """Test basic key creation."""
        key = SecretKey("my-secret")
        assert key.value == "my-secret"

    def test_empty_key_raises(self) -> None:
        """Test that empty key raises ValueError."""
        with pytest.raises(ValueError, match="cannot be empty"):
            SecretKey("")

    def test_equality_same_value(self) -> None:
        """Test equality of keys with same value."""
        key1 = SecretKey("same-key")
        key2 = SecretKey("same-key")
        assert key1 == key2

    def test_equality_different_value(self) -> None:
        """Test inequality of keys with different values."""
        key1 = SecretKey("key-one")
        key2 = SecretKey("key-two")
        assert key1 != key2

    def test_hash_consistency(self) -> None:
        """Test that equal keys have equal hashes."""
        key1 = SecretKey("hash-test")
        key2 = SecretKey("hash-test")
        assert hash(key1) == hash(key2)

    def test_repr_hides_value(self) -> None:
        """Test that repr doesn't expose the actual key value."""
        key = SecretKey("super-secret-value")
        repr_str = repr(key)
        assert "super-secret-value" not in repr_str
        assert "SecretKey" in repr_str
        assert "hash=" in repr_str

    def test_str_hides_value(self) -> None:
        """Test that str doesn't expose the actual key value."""
        key = SecretKey("another-secret")
        str_repr = str(key)
        assert "another-secret" not in str_repr

    def test_derive_subkey(self) -> None:
        """Test subkey derivation."""
        master = SecretKey("master-key")
        subkey1 = master.derive_subkey("encryption")
        subkey2 = master.derive_subkey("signing")
        subkey1_again = master.derive_subkey("encryption")

        # Different purposes yield different keys
        assert subkey1 != subkey2

        # Same purpose yields same key
        assert subkey1 == subkey1_again

        # Subkeys are different from master
        assert subkey1 != master

    def test_generate(self) -> None:
        """Test random key generation."""
        key1 = SecretKey.generate()
        key2 = SecretKey.generate()

        # Generated keys should be different
        assert key1 != key2

        # Generated keys should have reasonable length
        assert len(key1.value) == 64  # 32 bytes as hex

    def test_immutability(self) -> None:
        """Test that SecretKey is immutable (frozen dataclass)."""
        key = SecretKey("immutable")
        with pytest.raises(AttributeError):
            key._value = "modified"  # type: ignore


class TestSecretKeyConstantTimeComparison:
    """Tests for timing-safe comparison."""

    def test_constant_time_equal(self) -> None:
        """Test that equal keys use constant-time comparison."""
        key1 = SecretKey("test")
        key2 = SecretKey("test")

        # This should use secrets.compare_digest internally
        assert key1 == key2

    def test_constant_time_not_equal(self) -> None:
        """Test that unequal keys use constant-time comparison."""
        key1 = SecretKey("first")
        key2 = SecretKey("second")

        # This should use secrets.compare_digest internally
        assert key1 != key2

    def test_comparison_with_non_key(self) -> None:
        """Test comparison with non-SecretKey returns NotImplemented."""
        key = SecretKey("test")
        assert key != "test"  # String comparison
        assert key != 123  # Int comparison
        assert key != None  # None comparison
