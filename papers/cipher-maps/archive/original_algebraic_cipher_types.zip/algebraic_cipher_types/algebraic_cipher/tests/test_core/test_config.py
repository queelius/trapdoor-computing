"""Tests for EncodingConfig."""

import pytest
from algebraic_cipher.core.config import (
    EncodingConfig,
    HashStrategy,
    DEFAULT_CONFIG,
    HIGH_SECURITY_CONFIG,
    FAST_CONFIG,
)


class TestEncodingConfig:
    """Tests for EncodingConfig class."""

    def test_default_values(self) -> None:
        """Test default configuration values."""
        config = EncodingConfig()
        assert config.security_parameter == 128
        assert config.false_positive_rate == 1e-9
        assert config.false_negative_rate == 0.0
        assert config.use_randomization is False
        assert config.hash_strategy == HashStrategy.BALANCED
        assert config.representation_index == 0

    def test_custom_values(self) -> None:
        """Test custom configuration values."""
        config = EncodingConfig(
            security_parameter=256,
            false_positive_rate=1e-15,
            use_randomization=True,
            hash_strategy=HashStrategy.SECURE,
        )
        assert config.security_parameter == 256
        assert config.false_positive_rate == 1e-15
        assert config.use_randomization is True
        assert config.hash_strategy == HashStrategy.SECURE

    def test_invalid_security_parameter(self) -> None:
        """Test that invalid security parameters raise ValueError."""
        with pytest.raises(ValueError, match="security_parameter"):
            EncodingConfig(security_parameter=64)

        with pytest.raises(ValueError, match="security_parameter"):
            EncodingConfig(security_parameter=512)

    def test_invalid_false_positive_rate(self) -> None:
        """Test that invalid false positive rates raise ValueError."""
        with pytest.raises(ValueError, match="false_positive_rate"):
            EncodingConfig(false_positive_rate=-0.1)

        with pytest.raises(ValueError, match="false_positive_rate"):
            EncodingConfig(false_positive_rate=1.5)

    def test_invalid_false_negative_rate(self) -> None:
        """Test that invalid false negative rates raise ValueError."""
        with pytest.raises(ValueError, match="false_negative_rate"):
            EncodingConfig(false_negative_rate=-0.01)

    def test_invalid_representation_index(self) -> None:
        """Test that negative representation index raises ValueError."""
        with pytest.raises(ValueError, match="representation_index"):
            EncodingConfig(representation_index=-1)

    def test_immutability(self) -> None:
        """Test that EncodingConfig is immutable."""
        config = EncodingConfig()
        with pytest.raises(AttributeError):
            config.security_parameter = 256  # type: ignore


class TestPredefinedConfigs:
    """Tests for predefined configuration instances."""

    def test_default_config(self) -> None:
        """Test DEFAULT_CONFIG values."""
        assert DEFAULT_CONFIG.security_parameter == 128
        assert DEFAULT_CONFIG.use_randomization is False

    def test_high_security_config(self) -> None:
        """Test HIGH_SECURITY_CONFIG values."""
        assert HIGH_SECURITY_CONFIG.security_parameter == 256
        assert HIGH_SECURITY_CONFIG.false_positive_rate == 1e-15
        assert HIGH_SECURITY_CONFIG.use_randomization is True
        assert HIGH_SECURITY_CONFIG.hash_strategy == HashStrategy.SECURE

    def test_fast_config(self) -> None:
        """Test FAST_CONFIG values."""
        assert FAST_CONFIG.security_parameter == 128
        assert FAST_CONFIG.false_positive_rate == 1e-6
        assert FAST_CONFIG.use_randomization is False
        assert FAST_CONFIG.hash_strategy == HashStrategy.FAST


class TestHashStrategy:
    """Tests for HashStrategy enum."""

    def test_all_strategies_exist(self) -> None:
        """Test that all expected strategies exist."""
        assert HashStrategy.FAST
        assert HashStrategy.SECURE
        assert HashStrategy.BALANCED

    def test_strategies_are_distinct(self) -> None:
        """Test that strategies are distinct values."""
        strategies = [HashStrategy.FAST, HashStrategy.SECURE, HashStrategy.BALANCED]
        assert len(strategies) == len(set(strategies))
