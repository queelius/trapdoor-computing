"""Property-based tests for algebraic laws.

Tests that cipher types satisfy the expected algebraic laws:
- Ring laws for integers
- Boolean algebra laws for booleans
"""

import pytest

try:
    from hypothesis import given, strategies as st, assume, settings

    HYPOTHESIS_AVAILABLE = True
except ImportError:
    HYPOTHESIS_AVAILABLE = False
    pytest.skip("hypothesis not installed", allow_module_level=True)

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.boolean import CipherBool
from algebraic_cipher.types.integer import CipherInteger


# Fixed key for property tests (deterministic)
TEST_KEY = SecretKey("property-test-key-fixed")


class TestBooleanAlgebraLaws:
    """Property tests for Boolean algebra laws."""

    @given(st.booleans())
    @settings(max_examples=20)
    def test_double_negation(self, a: bool) -> None:
        """Test ~~a == a (double negation)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        result = ~~ca
        assert result.decrypt(TEST_KEY) == a

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_and_commutativity(self, a: bool, b: bool) -> None:
        """Test a && b == b && a."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        left = (ca & cb).decrypt(TEST_KEY)
        right = (cb & ca).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_or_commutativity(self, a: bool, b: bool) -> None:
        """Test a || b == b || a."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        left = (ca | cb).decrypt(TEST_KEY)
        right = (cb | ca).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans(), st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_and_associativity(self, a: bool, b: bool, c: bool) -> None:
        """Test (a && b) && c == a && (b && c)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)
        cc = CipherBool.encrypt(c, TEST_KEY)

        left = ((ca & cb) & cc).decrypt(TEST_KEY)
        right = (ca & (cb & cc)).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans(), st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_or_associativity(self, a: bool, b: bool, c: bool) -> None:
        """Test (a || b) || c == a || (b || c)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)
        cc = CipherBool.encrypt(c, TEST_KEY)

        left = ((ca | cb) | cc).decrypt(TEST_KEY)
        right = (ca | (cb | cc)).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans())
    @settings(max_examples=10)
    def test_and_identity(self, a: bool) -> None:
        """Test a && true == a."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        ct = CipherBool.true_(TEST_KEY)

        result = (ca & ct).decrypt(TEST_KEY)
        assert result == a

    @given(st.booleans())
    @settings(max_examples=10)
    def test_or_identity(self, a: bool) -> None:
        """Test a || false == a."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cf = CipherBool.false_(TEST_KEY)

        result = (ca | cf).decrypt(TEST_KEY)
        assert result == a

    @given(st.booleans())
    @settings(max_examples=10)
    def test_and_annihilator(self, a: bool) -> None:
        """Test a && false == false."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cf = CipherBool.false_(TEST_KEY)

        result = (ca & cf).decrypt(TEST_KEY)
        assert result is False

    @given(st.booleans())
    @settings(max_examples=10)
    def test_or_annihilator(self, a: bool) -> None:
        """Test a || true == true."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        ct = CipherBool.true_(TEST_KEY)

        result = (ca | ct).decrypt(TEST_KEY)
        assert result is True

    @given(st.booleans())
    @settings(max_examples=10)
    def test_complement_and(self, a: bool) -> None:
        """Test a && ~a == false."""
        ca = CipherBool.encrypt(a, TEST_KEY)

        result = (ca & ~ca).decrypt(TEST_KEY)
        assert result is False

    @given(st.booleans())
    @settings(max_examples=10)
    def test_complement_or(self, a: bool) -> None:
        """Test a || ~a == true."""
        ca = CipherBool.encrypt(a, TEST_KEY)

        result = (ca | ~ca).decrypt(TEST_KEY)
        assert result is True

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_de_morgan_and(self, a: bool, b: bool) -> None:
        """Test ~(a && b) == ~a || ~b (De Morgan's law)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        left = (~(ca & cb)).decrypt(TEST_KEY)
        right = ((~ca) | (~cb)).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_de_morgan_or(self, a: bool, b: bool) -> None:
        """Test ~(a || b) == ~a && ~b (De Morgan's law)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        left = (~(ca | cb)).decrypt(TEST_KEY)
        right = ((~ca) & (~cb)).decrypt(TEST_KEY)
        assert left == right

    @given(st.booleans(), st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_distributivity_and_over_or(self, a: bool, b: bool, c: bool) -> None:
        """Test a && (b || c) == (a && b) || (a && c)."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)
        cc = CipherBool.encrypt(c, TEST_KEY)

        left = (ca & (cb | cc)).decrypt(TEST_KEY)
        right = ((ca & cb) | (ca & cc)).decrypt(TEST_KEY)
        assert left == right


class TestIntegerRingLaws:
    """Property tests for integer ring laws."""

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_additive_identity(self, a: int) -> None:
        """Test a + 0 == a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        c0 = CipherInteger.zero(TEST_KEY)

        result = (ca + c0).decrypt(TEST_KEY)
        assert result == a

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_multiplicative_identity(self, a: int) -> None:
        """Test a * 1 == a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        c1 = CipherInteger.one(TEST_KEY)

        result = (ca * c1).decrypt(TEST_KEY)
        assert result == a

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_additive_inverse(self, a: int) -> None:
        """Test a + (-a) == 0."""
        ca = CipherInteger.encrypt(a, TEST_KEY)

        result = (ca + (-ca)).decrypt(TEST_KEY)
        assert result == 0

    @given(st.integers(min_value=-50, max_value=50), st.integers(min_value=-50, max_value=50))
    @settings(max_examples=20)
    def test_addition_commutativity(self, a: int, b: int) -> None:
        """Test a + b == b + a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        left = (ca + cb).decrypt(TEST_KEY)
        right = (cb + ca).decrypt(TEST_KEY)
        assert left == right

    @given(st.integers(min_value=-50, max_value=50), st.integers(min_value=-50, max_value=50))
    @settings(max_examples=20)
    def test_multiplication_commutativity(self, a: int, b: int) -> None:
        """Test a * b == b * a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        left = (ca * cb).decrypt(TEST_KEY)
        right = (cb * ca).decrypt(TEST_KEY)
        assert left == right

    @given(
        st.integers(min_value=-30, max_value=30),
        st.integers(min_value=-30, max_value=30),
        st.integers(min_value=-30, max_value=30),
    )
    @settings(max_examples=20)
    def test_addition_associativity(self, a: int, b: int, c: int) -> None:
        """Test (a + b) + c == a + (b + c)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)
        cc = CipherInteger.encrypt(c, TEST_KEY)

        left = ((ca + cb) + cc).decrypt(TEST_KEY)
        right = (ca + (cb + cc)).decrypt(TEST_KEY)
        assert left == right

    @given(
        st.integers(min_value=-10, max_value=10),
        st.integers(min_value=-10, max_value=10),
        st.integers(min_value=-10, max_value=10),
    )
    @settings(max_examples=20)
    def test_multiplication_associativity(self, a: int, b: int, c: int) -> None:
        """Test (a * b) * c == a * (b * c)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)
        cc = CipherInteger.encrypt(c, TEST_KEY)

        left = ((ca * cb) * cc).decrypt(TEST_KEY)
        right = (ca * (cb * cc)).decrypt(TEST_KEY)
        assert left == right

    @given(
        st.integers(min_value=-10, max_value=10),
        st.integers(min_value=-10, max_value=10),
        st.integers(min_value=-10, max_value=10),
    )
    @settings(max_examples=20)
    def test_distributivity(self, a: int, b: int, c: int) -> None:
        """Test a * (b + c) == (a * b) + (a * c)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)
        cc = CipherInteger.encrypt(c, TEST_KEY)

        left = (ca * (cb + cc)).decrypt(TEST_KEY)
        right = ((ca * cb) + (ca * cc)).decrypt(TEST_KEY)
        assert left == right

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_multiplicative_zero(self, a: int) -> None:
        """Test a * 0 == 0."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        c0 = CipherInteger.zero(TEST_KEY)

        result = (ca * c0).decrypt(TEST_KEY)
        assert result == 0

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_double_negation(self, a: int) -> None:
        """Test -(-a) == a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)

        result = (-(-ca)).decrypt(TEST_KEY)
        assert result == a
