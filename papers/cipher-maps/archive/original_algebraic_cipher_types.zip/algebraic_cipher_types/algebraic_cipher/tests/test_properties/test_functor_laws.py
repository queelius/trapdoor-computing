"""Property-based tests for functor and monad laws.

Tests that cipher types satisfy categorical laws:
- Functor laws: identity and composition
- Monad laws: left identity, right identity, associativity
"""

import pytest

try:
    from hypothesis import given, strategies as st, settings

    HYPOTHESIS_AVAILABLE = True
except ImportError:
    HYPOTHESIS_AVAILABLE = False
    pytest.skip("hypothesis not installed", allow_module_level=True)

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.sum import CipherOptional


# Fixed key for property tests
TEST_KEY = SecretKey("functor-monad-test-key")


class TestCipherOptionalFunctorLaws:
    """Test functor laws for CipherOptional."""

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_identity_some(self, x: int) -> None:
        """Test fmap(id) == id for Some values.

        Functor Law 1: fmap(id) == id
        """
        opt = CipherOptional.some(x, TEST_KEY)
        mapped = opt.fmap(lambda a: a)  # identity function

        assert mapped.decrypt(TEST_KEY) == x

    def test_identity_none(self) -> None:
        """Test fmap(id) == id for None values."""
        opt = CipherOptional.none(TEST_KEY)
        mapped = opt.fmap(lambda a: a)

        assert mapped.decrypt(TEST_KEY) is None

    @given(st.integers(min_value=-10, max_value=10))
    @settings(max_examples=20)
    def test_composition_some(self, x: int) -> None:
        """Test fmap(g . f) == fmap(g) . fmap(f).

        Functor Law 2: fmap(g . f) == fmap(g) . fmap(f)
        """
        f = lambda a: a + 1
        g = lambda b: b * 2

        opt = CipherOptional.some(x, TEST_KEY)

        # fmap(g . f)
        composed = opt.fmap(lambda a: g(f(a)))

        # fmap(g) . fmap(f)
        sequential = opt.fmap(f).fmap(g)

        assert composed.decrypt(TEST_KEY) == sequential.decrypt(TEST_KEY)

    def test_composition_none(self) -> None:
        """Test composition law for None values."""
        f = lambda a: a + 1
        g = lambda b: b * 2

        opt = CipherOptional.none(TEST_KEY)

        composed = opt.fmap(lambda a: g(f(a)))
        sequential = opt.fmap(f).fmap(g)

        # Both should still be None
        assert composed.decrypt(TEST_KEY) is None
        assert sequential.decrypt(TEST_KEY) is None


class TestCipherOptionalMonadLaws:
    """Test monad laws for CipherOptional."""

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_left_identity(self, x: int) -> None:
        """Test return(a).bind(f) == f(a).

        Monad Law 1: Left Identity
        """
        f = lambda a: CipherOptional.some(a * 2, TEST_KEY)

        # return(x).bind(f)
        left = CipherOptional.some(x, TEST_KEY).bind(f)

        # f(x)
        right = f(x)

        assert left.decrypt(TEST_KEY) == right.decrypt(TEST_KEY)

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_right_identity(self, x: int) -> None:
        """Test m.bind(return) == m.

        Monad Law 2: Right Identity
        """
        m = CipherOptional.some(x, TEST_KEY)

        # m.bind(return)
        result = m.bind(lambda a: CipherOptional.some(a, TEST_KEY))

        assert result.decrypt(TEST_KEY) == m.decrypt(TEST_KEY)

    def test_right_identity_none(self) -> None:
        """Test right identity for None values."""
        m = CipherOptional.none(TEST_KEY)

        result = m.bind(lambda a: CipherOptional.some(a, TEST_KEY))

        assert result.decrypt(TEST_KEY) is None

    @given(st.integers(min_value=-10, max_value=10))
    @settings(max_examples=20)
    def test_associativity(self, x: int) -> None:
        """Test m.bind(f).bind(g) == m.bind(lambda a: f(a).bind(g)).

        Monad Law 3: Associativity
        """
        f = lambda a: CipherOptional.some(a + 1, TEST_KEY)
        g = lambda b: CipherOptional.some(b * 2, TEST_KEY)

        m = CipherOptional.some(x, TEST_KEY)

        # m.bind(f).bind(g)
        left = m.bind(f).bind(g)

        # m.bind(lambda a: f(a).bind(g))
        right = m.bind(lambda a: f(a).bind(g))

        assert left.decrypt(TEST_KEY) == right.decrypt(TEST_KEY)

    def test_associativity_with_none(self) -> None:
        """Test associativity when None is involved."""

        def f(a: int) -> CipherOptional:
            return CipherOptional.some(a + 1, TEST_KEY) if a >= 0 else CipherOptional.none(TEST_KEY)

        def g(b: int) -> CipherOptional:
            return CipherOptional.some(b * 2, TEST_KEY)

        # Test with value that produces None
        m = CipherOptional.some(-5, TEST_KEY)

        left = m.bind(f).bind(g)
        right = m.bind(lambda a: f(a).bind(g))

        assert left.decrypt(TEST_KEY) == right.decrypt(TEST_KEY)
        assert left.decrypt(TEST_KEY) is None


class TestMonadLawsWithFailure:
    """Test monad laws when operations can fail."""

    def test_bind_short_circuits_on_none(self) -> None:
        """Test that bind short-circuits when encountering None."""
        # Simulates safe division
        def safe_div(x: int, y: int) -> CipherOptional:
            if y == 0:
                return CipherOptional.none(TEST_KEY)
            return CipherOptional.some(x // y, TEST_KEY)

        # Chain operations that might fail
        result = (
            CipherOptional.some(10, TEST_KEY)
            .bind(lambda x: safe_div(x, 2))   # 10 / 2 = 5
            .bind(lambda x: safe_div(x, 0))   # 5 / 0 = None
            .bind(lambda x: safe_div(x, 2))   # Should not execute
        )

        assert result.decrypt(TEST_KEY) is None

    def test_bind_continues_on_some(self) -> None:
        """Test that bind continues when values are present."""

        def safe_div(x: int, y: int) -> CipherOptional:
            if y == 0:
                return CipherOptional.none(TEST_KEY)
            return CipherOptional.some(x // y, TEST_KEY)

        result = (
            CipherOptional.some(100, TEST_KEY)
            .bind(lambda x: safe_div(x, 2))   # 100 / 2 = 50
            .bind(lambda x: safe_div(x, 5))   # 50 / 5 = 10
            .bind(lambda x: safe_div(x, 2))   # 10 / 2 = 5
        )

        assert result.decrypt(TEST_KEY) == 5
