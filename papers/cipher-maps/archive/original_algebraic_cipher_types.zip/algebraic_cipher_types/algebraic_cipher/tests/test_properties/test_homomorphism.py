"""Property-based tests for homomorphic properties.

The fundamental law: decrypt(op(encrypt(a), encrypt(b))) == op(a, b)

Tests that all operations preserve this property.
"""

import pytest

try:
    from hypothesis import given, strategies as st, assume, settings

    HYPOTHESIS_AVAILABLE = True
except ImportError:
    HYPOTHESIS_AVAILABLE = False
    pytest.skip("hypothesis not installed", allow_module_level=True)

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.boolean import CipherBool
from algebraic_cipher.types.integer import CipherInteger
from algebraic_cipher.types.product import CipherPair, CipherTuple
from algebraic_cipher.types.sum import CipherOptional


# Fixed key for property tests
TEST_KEY = SecretKey("homomorphism-test-key")


class TestBooleanHomomorphism:
    """Test homomorphic property for boolean operations."""

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_and_homomorphism(self, a: bool, b: bool) -> None:
        """Test decrypt(E(a) & E(b)) == a and b."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        encrypted_result = ca & cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a and b)

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_or_homomorphism(self, a: bool, b: bool) -> None:
        """Test decrypt(E(a) | E(b)) == a or b."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        encrypted_result = ca | cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a or b)

    @given(st.booleans())
    @settings(max_examples=10)
    def test_not_homomorphism(self, a: bool) -> None:
        """Test decrypt(~E(a)) == not a."""
        ca = CipherBool.encrypt(a, TEST_KEY)

        encrypted_result = ~ca
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (not a)

    @given(st.booleans(), st.booleans())
    @settings(max_examples=20)
    def test_xor_homomorphism(self, a: bool, b: bool) -> None:
        """Test decrypt(E(a) ^ E(b)) == a xor b."""
        ca = CipherBool.encrypt(a, TEST_KEY)
        cb = CipherBool.encrypt(b, TEST_KEY)

        encrypted_result = ca ^ cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a != b)  # XOR is same as not-equal for bools


class TestIntegerHomomorphism:
    """Test homomorphic property for integer operations."""

    @given(st.integers(min_value=-1000, max_value=1000),
           st.integers(min_value=-1000, max_value=1000))
    @settings(max_examples=30)
    def test_addition_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a) + E(b)) == a + b."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca + cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == a + b

    @given(st.integers(min_value=-1000, max_value=1000),
           st.integers(min_value=-1000, max_value=1000))
    @settings(max_examples=30)
    def test_subtraction_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a) - E(b)) == a - b."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca - cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == a - b

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=30)
    def test_multiplication_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a) * E(b)) == a * b."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca * cb
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == a * b

    @given(st.integers(min_value=-1000, max_value=1000))
    @settings(max_examples=20)
    def test_negation_homomorphism(self, a: int) -> None:
        """Test decrypt(-E(a)) == -a."""
        ca = CipherInteger.encrypt(a, TEST_KEY)

        encrypted_result = -ca
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == -a


class TestIntegerComparisonHomomorphism:
    """Test homomorphic property for integer comparisons."""

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=30)
    def test_eq_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a).cipher_eq(E(b))) == (a == b)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca.cipher_eq(cb)
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a == b)

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=30)
    def test_lt_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a).cipher_lt(E(b))) == (a < b)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca.cipher_lt(cb)
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a < b)

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=30)
    def test_gt_homomorphism(self, a: int, b: int) -> None:
        """Test decrypt(E(a).cipher_gt(E(b))) == (a > b)."""
        ca = CipherInteger.encrypt(a, TEST_KEY)
        cb = CipherInteger.encrypt(b, TEST_KEY)

        encrypted_result = ca.cipher_gt(cb)
        decrypted = encrypted_result.decrypt(TEST_KEY)

        assert decrypted == (a > b)


class TestProductHomomorphism:
    """Test homomorphic property for product types."""

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_pair_encrypt_decrypt(self, a: int, b: int) -> None:
        """Test decrypt(encrypt((a, b))) == (a, b)."""
        pair = (a, b)
        cipher = CipherPair.encrypt(pair, TEST_KEY)
        decrypted = cipher.decrypt(TEST_KEY)

        assert decrypted == pair

    @given(st.integers(min_value=-50, max_value=50),
           st.integers(min_value=-50, max_value=50))
    @settings(max_examples=20)
    def test_pair_bimap_homomorphism(self, a: int, b: int) -> None:
        """Test bimap preserves homomorphism."""
        f = lambda x: x * 2
        g = lambda y: y + 1

        cipher = CipherPair.encrypt((a, b), TEST_KEY)
        mapped = cipher.bimap(f, g)
        decrypted = mapped.decrypt(TEST_KEY)

        assert decrypted == (f(a), g(b))

    @given(st.integers(min_value=-100, max_value=100),
           st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_pair_swap_homomorphism(self, a: int, b: int) -> None:
        """Test swap preserves homomorphism."""
        cipher = CipherPair.encrypt((a, b), TEST_KEY)
        swapped = cipher.swap()
        decrypted = swapped.decrypt(TEST_KEY)

        assert decrypted == (b, a)


class TestOptionalHomomorphism:
    """Test homomorphic property for optional types."""

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=20)
    def test_optional_some_encrypt_decrypt(self, x: int) -> None:
        """Test decrypt(encrypt(Some(x))) == x."""
        cipher = CipherOptional.some(x, TEST_KEY)
        decrypted = cipher.decrypt(TEST_KEY)

        assert decrypted == x

    def test_optional_none_encrypt_decrypt(self) -> None:
        """Test decrypt(encrypt(None)) == None."""
        cipher = CipherOptional.none(TEST_KEY)
        decrypted = cipher.decrypt(TEST_KEY)

        assert decrypted is None

    @given(st.integers(min_value=-50, max_value=50))
    @settings(max_examples=20)
    def test_optional_fmap_homomorphism(self, x: int) -> None:
        """Test fmap preserves homomorphism: decrypt(fmap(f, E(x))) == f(x)."""
        f = lambda a: a * 2

        cipher = CipherOptional.some(x, TEST_KEY)
        mapped = cipher.fmap(f)
        decrypted = mapped.decrypt(TEST_KEY)

        assert decrypted == f(x)


class TestKeyIsolation:
    """Test that wrong keys return None (key isolation property)."""

    @given(st.booleans())
    @settings(max_examples=10)
    def test_bool_key_isolation(self, a: bool) -> None:
        """Test that wrong key returns None for CipherBool."""
        key1 = SecretKey("key-one")
        key2 = SecretKey("key-two")

        cipher = CipherBool.encrypt(a, key1)
        result = cipher.decrypt(key2)

        assert result is None

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=10)
    def test_int_key_isolation(self, a: int) -> None:
        """Test that wrong key returns None for CipherInteger."""
        key1 = SecretKey("key-one")
        key2 = SecretKey("key-two")

        cipher = CipherInteger.encrypt(a, key1)
        result = cipher.decrypt(key2)

        assert result is None

    @given(st.integers(min_value=-100, max_value=100))
    @settings(max_examples=10)
    def test_optional_key_isolation(self, x: int) -> None:
        """Test that wrong key returns None for CipherOptional."""
        key1 = SecretKey("key-one")
        key2 = SecretKey("key-two")

        cipher = CipherOptional.some(x, key1)
        result = cipher.decrypt(key2)

        assert result is None
