"""Tests for cipher functions module."""
