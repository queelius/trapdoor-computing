"""Tests for function combinators."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.functions.domain import Domain
from algebraic_cipher.functions.cipher_function import CipherFunction
from algebraic_cipher.functions.combinators import (
    identity,
    constant,
    compose,
    product,
    curry,
    fanout,
    parallel,
    map_optional,
)
from algebraic_cipher.types.integer import CipherInteger


class TestIdentity:
    """Tests for identity combinator."""

    def test_identity_returns_input(self) -> None:
        """Test that identity returns its input."""
        dom = Domain.from_range(0, 10)
        id_fn = identity(dom)

        for x in range(11):
            assert id_fn(x) == x

    def test_identity_homomorphism(self, test_key: SecretKey) -> None:
        """Test identity preserves encrypted values."""
        dom = Domain.from_range(0, 10)
        id_fn = identity(dom)

        encrypted = CipherInteger.encrypt(5, test_key)
        result = id_fn.apply(encrypted, test_key)
        assert result.decrypt(test_key) == 5


class TestConstant:
    """Tests for constant combinator."""

    def test_constant_returns_value(self) -> None:
        """Test that constant returns the fixed value."""
        dom = Domain.from_range(0, 10)
        always_42 = constant(42, dom)

        for x in range(11):
            assert always_42(x) == 42

    def test_constant_homomorphism(self, test_key: SecretKey) -> None:
        """Test constant preserves in encrypted domain."""
        dom = Domain.from_range(0, 10)
        always_42 = constant(42, dom)

        for x in range(0, 11, 3):
            encrypted = CipherInteger.encrypt(x, test_key)
            result = always_42.apply(encrypted, test_key)
            assert result.decrypt(test_key) == 42


class TestCompose:
    """Tests for compose combinator."""

    def test_compose_applies_in_order(self) -> None:
        """Test that compose applies f then g."""
        add_one = CipherFunction.from_function(lambda x: x + 1, Domain.from_range(0, 10))
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(1, 11))

        # compose(double, add_one)(x) = double(add_one(x)) = (x + 1) * 2
        composed = compose(double, add_one)

        assert composed(5) == 12  # (5 + 1) * 2 = 12
        assert composed(0) == 2   # (0 + 1) * 2 = 2

    def test_compose_homomorphism(self, test_key: SecretKey) -> None:
        """Test compose preserves homomorphism."""
        add_one = CipherFunction.from_function(lambda x: x + 1, Domain.from_range(0, 10))
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(1, 11))
        composed = compose(double, add_one)

        encrypted = CipherInteger.encrypt(5, test_key)
        result = composed.apply(encrypted, test_key)
        assert result.decrypt(test_key) == 12


class TestProduct:
    """Tests for product combinator."""

    def test_product_applies_to_components(self) -> None:
        """Test that product applies functions to pair components."""
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 5))
        square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 5))

        prod = product(double, square)

        assert prod((3, 4)) == (6, 16)
        assert prod((0, 0)) == (0, 0)
        assert prod((2, 3)) == (4, 9)


class TestCurry:
    """Tests for curry combinator."""

    def test_curry_fixes_first_argument(self) -> None:
        """Test that curry fixes the first argument."""
        # Create a function on pairs
        add_pair = CipherFunction.from_function(
            lambda p: p[0] + p[1],
            Domain.from_values([(i, j) for i in range(5) for j in range(5)])
        )

        # Curry with x = 3
        add_3 = curry(add_pair, 3, Domain.from_range(0, 4))

        assert add_3(0) == 3
        assert add_3(2) == 5
        assert add_3(4) == 7


class TestFanout:
    """Tests for fanout combinator."""

    def test_fanout_applies_both(self) -> None:
        """Test that fanout applies both functions."""
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 10))
        square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 10))

        both = fanout(double, square)

        assert both(3) == (6, 9)
        assert both(5) == (10, 25)


class TestParallel:
    """Tests for parallel combinator."""

    def test_parallel_applies_all(self) -> None:
        """Test that parallel applies all functions."""
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 10))
        square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 10))
        negate = CipherFunction.from_function(lambda x: -x, Domain.from_range(0, 10))

        all_three = parallel(double, square, negate)

        assert all_three(3) == (6, 9, -3)
        assert all_three(5) == (10, 25, -5)

    def test_parallel_requires_at_least_one(self) -> None:
        """Test that parallel requires at least one function."""
        with pytest.raises(ValueError, match="At least one function"):
            parallel()


class TestMapOptional:
    """Tests for map_optional combinator."""

    def test_map_optional_some(self) -> None:
        """Test map_optional with Some value."""
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 10))
        maybe_double = map_optional(double)

        assert maybe_double(5) == 10
        assert maybe_double(0) == 0

    def test_map_optional_none(self) -> None:
        """Test map_optional with None value."""
        double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 10))
        maybe_double = map_optional(double)

        assert maybe_double(None) is None
