"""Tests for Domain class."""

import pytest
from algebraic_cipher.functions.domain import Domain


class TestDomainCreation:
    """Tests for domain creation."""

    def test_from_values(self) -> None:
        """Test domain from explicit values."""
        dom = Domain.from_values([3, 1, 2])
        assert len(dom) == 3
        assert list(dom) == [1, 2, 3]  # Sorted

    def test_from_values_with_duplicates(self) -> None:
        """Test that duplicates are removed."""
        dom = Domain.from_values([1, 2, 2, 3, 3, 3])
        assert len(dom) == 3
        assert list(dom) == [1, 2, 3]

    def test_from_range(self) -> None:
        """Test domain from integer range."""
        dom = Domain.from_range(0, 10)
        assert len(dom) == 11
        assert 0 in dom
        assert 10 in dom
        assert 11 not in dom

    def test_from_range_invalid(self) -> None:
        """Test that invalid range raises ValueError."""
        with pytest.raises(ValueError, match="must be >="):
            Domain.from_range(10, 5)

    def test_boolean(self) -> None:
        """Test boolean domain."""
        dom = Domain.boolean()
        assert len(dom) == 2
        assert False in dom
        assert True in dom

    def test_singleton(self) -> None:
        """Test singleton domain."""
        dom = Domain.singleton(42)
        assert len(dom) == 1
        assert 42 in dom
        assert 0 not in dom

    def test_empty(self) -> None:
        """Test empty domain."""
        dom = Domain.empty()
        assert len(dom) == 0
        assert 0 not in dom


class TestDomainContainment:
    """Tests for domain containment."""

    def test_contains_discrete(self) -> None:
        """Test containment in discrete domain."""
        dom = Domain.from_values([1, 2, 3])
        assert 1 in dom
        assert 2 in dom
        assert 3 in dom
        assert 4 not in dom
        assert 0 not in dom

    def test_contains_range(self) -> None:
        """Test containment in range domain."""
        dom = Domain.from_range(0, 100, max_enumerate=50)  # Don't enumerate
        assert 0 in dom
        assert 50 in dom
        assert 100 in dom
        assert -1 not in dom
        assert 101 not in dom


class TestDomainProperties:
    """Tests for domain properties."""

    def test_is_discrete(self) -> None:
        """Test is_discrete property."""
        discrete = Domain.from_values([1, 2, 3])
        assert discrete.is_discrete

    def test_min_max_discrete(self) -> None:
        """Test min/max for discrete domain."""
        dom = Domain.from_values([5, 2, 8, 1])
        assert dom.min == 1
        assert dom.max == 8

    def test_min_max_range(self) -> None:
        """Test min/max for range domain."""
        dom = Domain.from_range(10, 20)
        assert dom.min == 10
        assert dom.max == 20

    def test_is_empty(self) -> None:
        """Test is_empty method."""
        empty = Domain.empty()
        non_empty = Domain.from_values([1])

        assert empty.is_empty()
        assert not non_empty.is_empty()

    def test_values_property(self) -> None:
        """Test values property."""
        dom = Domain.from_values([3, 1, 2])
        assert dom.values == (1, 2, 3)


class TestDomainOperations:
    """Tests for domain operations."""

    def test_union(self) -> None:
        """Test domain union."""
        d1 = Domain.from_values([1, 2, 3])
        d2 = Domain.from_values([3, 4, 5])
        union = d1.union(d2)

        assert 1 in union
        assert 3 in union
        assert 5 in union
        assert len(union) == 5

    def test_intersection(self) -> None:
        """Test domain intersection."""
        d1 = Domain.from_values([1, 2, 3, 4])
        d2 = Domain.from_values([3, 4, 5, 6])
        inter = d1.intersection(d2)

        assert 3 in inter
        assert 4 in inter
        assert 1 not in inter
        assert 5 not in inter
        assert len(inter) == 2

    def test_map(self) -> None:
        """Test domain mapping."""
        dom = Domain.from_values([1, 2, 3])
        mapped = dom.map(lambda x: x * 2)

        assert list(mapped) == [2, 4, 6]


class TestDomainIteration:
    """Tests for domain iteration."""

    def test_iterate_discrete(self) -> None:
        """Test iteration over discrete domain."""
        dom = Domain.from_values([1, 2, 3])
        values = list(dom)
        assert values == [1, 2, 3]

    def test_iterate_range(self) -> None:
        """Test iteration over range domain."""
        dom = Domain.from_range(0, 5)
        values = list(dom)
        assert values == [0, 1, 2, 3, 4, 5]
