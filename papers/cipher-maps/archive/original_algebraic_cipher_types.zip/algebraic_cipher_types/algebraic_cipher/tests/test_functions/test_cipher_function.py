"""Tests for CipherFunction."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.functions.domain import Domain
from algebraic_cipher.functions.cipher_function import (
    CipherFunction,
    FunctionConfig,
    CipherFunctionBuilder,
)
from algebraic_cipher.types.integer import CipherInteger


class TestCipherFunctionBasic:
    """Basic tests for CipherFunction."""

    def test_create_from_function(self) -> None:
        """Test creating a cipher function."""
        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10)
        )
        assert fn.is_valid()
        assert len(fn.domain) == 11

    def test_call_plain_value(self) -> None:
        """Test calling with plain value."""
        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10)
        )
        assert fn(5) == 10

    def test_apply_encrypted(self, test_key: SecretKey) -> None:
        """Test applying to encrypted value."""
        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10)
        )

        encrypted_5 = CipherInteger.encrypt(5, test_key)
        result = fn.apply(encrypted_5, test_key)
        assert result.decrypt(test_key) == 10

    def test_statistics(self) -> None:
        """Test getting function statistics."""
        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 100)
        )

        stats = fn.get_statistics()
        assert stats.domain_size == 101
        assert stats.num_bins > 0

    def test_domain_property(self) -> None:
        """Test domain property."""
        dom = Domain.from_range(0, 10)
        fn = CipherFunction.from_function(lambda x: x, dom)
        assert fn.domain is dom

    def test_value_not_in_domain(self, test_key: SecretKey) -> None:
        """Test that values outside domain raise error."""
        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10)
        )

        encrypted_20 = CipherInteger.encrypt(20, test_key)
        with pytest.raises(ValueError, match="not in function domain"):
            fn.apply(encrypted_20, test_key)


class TestCipherFunctionConfig:
    """Tests for function configuration."""

    def test_default_config(self) -> None:
        """Test default configuration values."""
        config = FunctionConfig()
        assert config.num_bins == 0  # Auto-select
        assert config.max_seed_attempts == 1000
        assert config.seed is None
        assert config.enable_cache is True
        assert config.optimization_level == 1

    def test_custom_config(self) -> None:
        """Test custom configuration."""
        config = FunctionConfig(
            num_bins=64,
            max_seed_attempts=500,
            seed=12345,
            enable_cache=False,
            optimization_level=2
        )

        fn = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 100),
            config
        )

        stats = fn.get_statistics()
        assert stats.num_bins == 64

    def test_deterministic_with_seed(self) -> None:
        """Test that same seed produces consistent results."""
        config = FunctionConfig(seed=42)

        fn1 = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10),
            config
        )

        fn2 = CipherFunction.from_function(
            lambda x: x * 2,
            Domain.from_range(0, 10),
            config
        )

        # Both should produce same output
        for x in range(11):
            assert fn1(x) == fn2(x)


class TestCipherFunctionBuilder:
    """Tests for CipherFunctionBuilder."""

    def test_builder_pattern(self) -> None:
        """Test builder pattern."""
        fn = (
            CipherFunctionBuilder[int, int]()
            .with_function(lambda x: x * 2)
            .with_domain(Domain.from_range(0, 10))
            .build()
        )

        assert fn.is_valid()
        assert fn(5) == 10

    def test_builder_with_config(self) -> None:
        """Test builder with custom config."""
        fn = (
            CipherFunctionBuilder[int, int]()
            .with_function(lambda x: x + 1)
            .with_domain(Domain.from_range(0, 100))
            .with_config(FunctionConfig(num_bins=32))
            .build()
        )

        assert fn.get_statistics().num_bins == 32

    def test_builder_missing_function_raises(self) -> None:
        """Test that missing function raises ValueError."""
        builder = CipherFunctionBuilder[int, int]().with_domain(Domain.from_range(0, 10))

        with pytest.raises(ValueError, match="Function not set"):
            builder.build()

    def test_builder_missing_domain_raises(self) -> None:
        """Test that missing domain raises ValueError."""
        builder = CipherFunctionBuilder[int, int]().with_function(lambda x: x)

        with pytest.raises(ValueError, match="Domain not set"):
            builder.build()


class TestCipherFunctionHomomorphism:
    """Tests verifying the homomorphic property."""

    def test_square_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(apply(E(x))) == f(x) for square function."""
        fn = CipherFunction.from_function(
            lambda x: x * x,
            Domain.from_range(0, 10)
        )

        for x in range(11):
            encrypted = CipherInteger.encrypt(x, test_key)
            result = fn.apply(encrypted, test_key)
            assert result.decrypt(test_key) == x * x

    def test_increment_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(apply(E(x))) == f(x) for increment function."""
        fn = CipherFunction.from_function(
            lambda x: x + 1,
            Domain.from_range(0, 50)
        )

        for x in range(0, 51, 10):
            encrypted = CipherInteger.encrypt(x, test_key)
            result = fn.apply(encrypted, test_key)
            assert result.decrypt(test_key) == x + 1

    def test_boolean_function_homomorphism(self, test_key: SecretKey) -> None:
        """Test homomorphism for boolean-returning function."""
        fn = CipherFunction.from_function(
            lambda x: x > 5,
            Domain.from_range(0, 10)
        )

        for x in range(11):
            encrypted = CipherInteger.encrypt(x, test_key)
            result = fn.apply(encrypted, test_key)
            assert result.decrypt(test_key) == (x > 5)
