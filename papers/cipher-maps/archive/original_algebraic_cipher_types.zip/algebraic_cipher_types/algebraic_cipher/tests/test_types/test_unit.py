"""Tests for Unit type and CipherUnit."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.unit import Unit, CipherUnit, UNIT


class TestUnit:
    """Tests for Unit type."""

    def test_singleton(self) -> None:
        """Test that Unit is a singleton."""
        u1 = Unit()
        u2 = Unit()
        assert u1 is u2
        assert u1 is UNIT

    def test_equality(self) -> None:
        """Test that all units are equal."""
        u1 = Unit()
        u2 = Unit()
        assert u1 == u2

    def test_inequality_with_other_types(self) -> None:
        """Test that unit is not equal to non-unit values."""
        u = Unit()
        assert u != None
        assert u != ()
        assert u != 0
        assert u != ""

    def test_hash(self) -> None:
        """Test that unit has consistent hash."""
        u1 = Unit()
        u2 = Unit()
        assert hash(u1) == hash(u2)

    def test_repr(self) -> None:
        """Test unit representation."""
        u = Unit()
        assert repr(u) == "Unit()"

    def test_str(self) -> None:
        """Test unit string representation."""
        u = Unit()
        assert str(u) == "()"


class TestCipherUnit:
    """Tests for CipherUnit class."""

    def test_encrypt_decrypt(self, test_key: SecretKey) -> None:
        """Test basic encryption and decryption."""
        cipher = CipherUnit.encrypt(UNIT, test_key)
        result = cipher.decrypt(test_key)
        assert result == UNIT
        assert result is UNIT

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        cipher = CipherUnit.encrypt(UNIT, test_key)
        result = cipher.decrypt(alt_key)
        assert result is None

    def test_encrypt_non_unit_raises(self, test_key: SecretKey) -> None:
        """Test that encrypting non-unit raises TypeError."""
        with pytest.raises(TypeError, match="Expected Unit"):
            CipherUnit.encrypt(None, test_key)  # type: ignore

        with pytest.raises(TypeError, match="Expected Unit"):
            CipherUnit.encrypt((), test_key)  # type: ignore

    def test_is_valid(self, test_key: SecretKey) -> None:
        """Test is_valid method."""
        valid_cipher = CipherUnit.encrypt(UNIT, test_key)
        assert valid_cipher.is_valid()

        invalid_cipher = CipherUnit()
        assert not invalid_cipher.is_valid()

    def test_error_rates(self, test_key: SecretKey) -> None:
        """Test that error rates are zero."""
        cipher = CipherUnit.encrypt(UNIT, test_key)
        assert cipher.false_positive_rate == 0.0
        assert cipher.false_negative_rate == 0.0
