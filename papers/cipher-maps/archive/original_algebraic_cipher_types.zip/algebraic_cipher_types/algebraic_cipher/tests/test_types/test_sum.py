"""Tests for sum types (Either, CipherEither, CipherOptional)."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.sum import Either, CipherEither, CipherOptional


class TestEither:
    """Tests for Either type."""

    def test_left(self) -> None:
        """Test Left variant creation."""
        e = Either.left("error")
        assert e.is_left()
        assert not e.is_right()
        assert e.get_left() == "error"

    def test_right(self) -> None:
        """Test Right variant creation."""
        e = Either.right(42)
        assert e.is_right()
        assert not e.is_left()
        assert e.get_right() == 42

    def test_get_left_from_right_raises(self) -> None:
        """Test that get_left on Right raises ValueError."""
        e = Either.right(42)
        with pytest.raises(ValueError, match="Cannot get left"):
            e.get_left()

    def test_get_right_from_left_raises(self) -> None:
        """Test that get_right on Left raises ValueError."""
        e = Either.left("error")
        with pytest.raises(ValueError, match="Cannot get right"):
            e.get_right()

    def test_match_left(self) -> None:
        """Test pattern matching on Left."""
        e = Either.left("error")
        result = e.match(
            lambda l: f"Error: {l}",
            lambda r: f"Value: {r}"
        )
        assert result == "Error: error"

    def test_match_right(self) -> None:
        """Test pattern matching on Right."""
        e = Either.right(42)
        result = e.match(
            lambda l: f"Error: {l}",
            lambda r: f"Value: {r}"
        )
        assert result == "Value: 42"

    def test_map_left(self) -> None:
        """Test map_left operation."""
        left = Either.left("error")
        right = Either.right(42)

        mapped_left = left.map_left(str.upper)
        mapped_right = right.map_left(str.upper)

        assert mapped_left.get_left() == "ERROR"
        assert mapped_right.get_right() == 42

    def test_map_right(self) -> None:
        """Test map_right operation."""
        left = Either.left("error")
        right = Either.right(42)

        mapped_left = left.map_right(lambda x: x * 2)
        mapped_right = right.map_right(lambda x: x * 2)

        assert mapped_left.get_left() == "error"
        assert mapped_right.get_right() == 84

    def test_bimap(self) -> None:
        """Test bimap operation."""
        left = Either.left("error")
        right = Either.right(42)

        mapped_left = left.bimap(str.upper, lambda x: x * 2)
        mapped_right = right.bimap(str.upper, lambda x: x * 2)

        assert mapped_left.get_left() == "ERROR"
        assert mapped_right.get_right() == 84


class TestCipherEither:
    """Tests for CipherEither class."""

    def test_encrypt_decrypt_left(self, test_key: SecretKey) -> None:
        """Test encryption and decryption of Left."""
        e = Either.left("error")
        cipher = CipherEither.encrypt(e, test_key)
        result = cipher.decrypt(test_key)
        assert result is not None
        assert result.is_left()
        assert result.get_left() == "error"

    def test_encrypt_decrypt_right(self, test_key: SecretKey) -> None:
        """Test encryption and decryption of Right."""
        e = Either.right(42)
        cipher = CipherEither.encrypt(e, test_key)
        result = cipher.decrypt(test_key)
        assert result is not None
        assert result.is_right()
        assert result.get_right() == 42

    def test_from_left(self, test_key: SecretKey) -> None:
        """Test from_left factory method."""
        cipher = CipherEither.from_left("error", test_key)
        result = cipher.decrypt(test_key)
        assert result is not None
        assert result.is_left()

    def test_from_right(self, test_key: SecretKey) -> None:
        """Test from_right factory method."""
        cipher = CipherEither.from_right(42, test_key)
        result = cipher.decrypt(test_key)
        assert result is not None
        assert result.is_right()

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        cipher = CipherEither.from_right(42, test_key)
        result = cipher.decrypt(alt_key)
        assert result is None

    def test_map_left(self, test_key: SecretKey) -> None:
        """Test encrypted map_left."""
        cipher = CipherEither.from_left("error", test_key)
        mapped = cipher.map_left(str.upper)
        result = mapped.decrypt(test_key)
        assert result is not None
        assert result.get_left() == "ERROR"

    def test_map_right(self, test_key: SecretKey) -> None:
        """Test encrypted map_right."""
        cipher = CipherEither.from_right(21, test_key)
        mapped = cipher.map_right(lambda x: x * 2)
        result = mapped.decrypt(test_key)
        assert result is not None
        assert result.get_right() == 42

    def test_is_left_cipher(self, test_key: SecretKey) -> None:
        """Test is_left returns encrypted boolean."""
        left = CipherEither.from_left("error", test_key)
        right = CipherEither.from_right(42, test_key)

        assert left.is_left().decrypt(test_key) is True
        assert right.is_left().decrypt(test_key) is False

    def test_is_right_cipher(self, test_key: SecretKey) -> None:
        """Test is_right returns encrypted boolean."""
        left = CipherEither.from_left("error", test_key)
        right = CipherEither.from_right(42, test_key)

        assert left.is_right().decrypt(test_key) is False
        assert right.is_right().decrypt(test_key) is True


class TestCipherOptional:
    """Tests for CipherOptional class."""

    def test_some(self, test_key: SecretKey) -> None:
        """Test Some variant."""
        cipher = CipherOptional.some(42, test_key)
        result = cipher.decrypt(test_key)
        assert result == 42

    def test_none(self, test_key: SecretKey) -> None:
        """Test None variant."""
        cipher = CipherOptional.none(test_key)
        result = cipher.decrypt(test_key)
        assert result is None

    def test_from_optional_some(self, test_key: SecretKey) -> None:
        """Test from_optional with Some value."""
        cipher = CipherOptional.from_optional(42, test_key)
        result = cipher.decrypt(test_key)
        assert result == 42

    def test_from_optional_none(self, test_key: SecretKey) -> None:
        """Test from_optional with None value."""
        cipher = CipherOptional.from_optional(None, test_key)
        result = cipher.decrypt(test_key)
        assert result is None

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        cipher = CipherOptional.some(42, test_key)
        result = cipher.decrypt(alt_key)
        assert result is None

    def test_decrypt_with_status_some(self, test_key: SecretKey) -> None:
        """Test decrypt_with_status for Some."""
        cipher = CipherOptional.some(42, test_key)
        valid, value = cipher.decrypt_with_status(test_key)
        assert valid is True
        assert value == 42

    def test_decrypt_with_status_none(self, test_key: SecretKey) -> None:
        """Test decrypt_with_status for None."""
        cipher = CipherOptional.none(test_key)
        valid, value = cipher.decrypt_with_status(test_key)
        assert valid is True
        assert value is None

    def test_decrypt_with_status_wrong_key(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test decrypt_with_status with wrong key."""
        cipher = CipherOptional.some(42, test_key)
        valid, value = cipher.decrypt_with_status(alt_key)
        assert valid is False
        assert value is None

    def test_fmap_some(self, test_key: SecretKey) -> None:
        """Test fmap on Some value."""
        cipher = CipherOptional.some(21, test_key)
        mapped = cipher.fmap(lambda x: x * 2)
        result = mapped.decrypt(test_key)
        assert result == 42

    def test_fmap_none(self, test_key: SecretKey) -> None:
        """Test fmap on None value."""
        cipher = CipherOptional.none(test_key)
        mapped = cipher.fmap(lambda x: x * 2)
        result = mapped.decrypt(test_key)
        assert result is None

    def test_bind_some_to_some(self, test_key: SecretKey) -> None:
        """Test bind returning Some."""
        cipher = CipherOptional.some(10, test_key)
        result = cipher.bind(lambda x: CipherOptional.some(x * 2, test_key))
        assert result.decrypt(test_key) == 20

    def test_bind_some_to_none(self, test_key: SecretKey) -> None:
        """Test bind returning None."""
        cipher = CipherOptional.some(0, test_key)
        result = cipher.bind(
            lambda x: CipherOptional.some(100 // x, test_key)
            if x != 0
            else CipherOptional.none(test_key)
        )
        assert result.decrypt(test_key) is None

    def test_bind_none(self, test_key: SecretKey) -> None:
        """Test bind on None value."""
        cipher = CipherOptional.none(test_key)
        result = cipher.bind(lambda x: CipherOptional.some(x * 2, test_key))
        assert result.decrypt(test_key) is None

    def test_is_some_cipher(self, test_key: SecretKey) -> None:
        """Test is_some returns encrypted boolean."""
        some = CipherOptional.some(42, test_key)
        none = CipherOptional.none(test_key)

        assert some.is_some().decrypt(test_key) is True
        assert none.is_some().decrypt(test_key) is False

    def test_is_none_cipher(self, test_key: SecretKey) -> None:
        """Test is_none returns encrypted boolean."""
        some = CipherOptional.some(42, test_key)
        none = CipherOptional.none(test_key)

        assert some.is_none().decrypt(test_key) is False
        assert none.is_none().decrypt(test_key) is True

    def test_get_or_else_some(self, test_key: SecretKey) -> None:
        """Test get_or_else with Some value."""
        cipher = CipherOptional.some(42, test_key)
        result = cipher.get_or_else(0, test_key)
        assert result == 42

    def test_get_or_else_none(self, test_key: SecretKey) -> None:
        """Test get_or_else with None value."""
        cipher = CipherOptional.none(test_key)
        result = cipher.get_or_else(0, test_key)
        assert result == 0
