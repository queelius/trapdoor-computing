"""Tests for CipherInteger."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.integer import CipherInteger


class TestCipherIntegerBasic:
    """Basic tests for CipherInteger."""

    def test_encrypt_decrypt(self, test_key: SecretKey) -> None:
        """Test basic encryption and decryption."""
        cipher = CipherInteger.encrypt(42, test_key)
        result = cipher.decrypt(test_key)
        assert result == 42

    def test_encrypt_decrypt_zero(self, test_key: SecretKey) -> None:
        """Test encryption of zero."""
        cipher = CipherInteger.encrypt(0, test_key)
        result = cipher.decrypt(test_key)
        assert result == 0

    def test_encrypt_decrypt_negative(self, test_key: SecretKey) -> None:
        """Test encryption of negative numbers."""
        cipher = CipherInteger.encrypt(-17, test_key)
        result = cipher.decrypt(test_key)
        assert result == -17

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        cipher = CipherInteger.encrypt(42, test_key)
        result = cipher.decrypt(alt_key)
        assert result is None

    def test_encrypt_non_int_raises(self, test_key: SecretKey) -> None:
        """Test that encrypting non-int raises TypeError."""
        with pytest.raises(TypeError, match="Expected int"):
            CipherInteger.encrypt(3.14, test_key)  # type: ignore

        with pytest.raises(TypeError, match="Expected int"):
            CipherInteger.encrypt("42", test_key)  # type: ignore

        # Note: bool is subclass of int, so we explicitly reject it
        with pytest.raises(TypeError, match="Expected int"):
            CipherInteger.encrypt(True, test_key)  # type: ignore

    def test_is_valid(self, test_key: SecretKey) -> None:
        """Test is_valid method."""
        valid_cipher = CipherInteger.encrypt(42, test_key)
        assert valid_cipher.is_valid()

        invalid_cipher = CipherInteger()
        assert not invalid_cipher.is_valid()

    def test_factory_methods(self, test_key: SecretKey) -> None:
        """Test zero and one factory methods."""
        zero = CipherInteger.zero(test_key)
        one = CipherInteger.one(test_key)

        assert zero.decrypt(test_key) == 0
        assert one.decrypt(test_key) == 1


class TestCipherIntegerArithmetic:
    """Tests for homomorphic arithmetic operations."""

    def test_addition(self, test_key: SecretKey) -> None:
        """Test homomorphic addition."""
        a = CipherInteger.encrypt(10, test_key)
        b = CipherInteger.encrypt(32, test_key)
        result = a + b
        assert result.decrypt(test_key) == 42

    def test_subtraction(self, test_key: SecretKey) -> None:
        """Test homomorphic subtraction."""
        a = CipherInteger.encrypt(50, test_key)
        b = CipherInteger.encrypt(8, test_key)
        result = a - b
        assert result.decrypt(test_key) == 42

    def test_multiplication(self, test_key: SecretKey) -> None:
        """Test homomorphic multiplication."""
        a = CipherInteger.encrypt(6, test_key)
        b = CipherInteger.encrypt(7, test_key)
        result = a * b
        assert result.decrypt(test_key) == 42

    def test_negation(self, test_key: SecretKey) -> None:
        """Test homomorphic negation."""
        a = CipherInteger.encrypt(42, test_key)
        result = -a
        assert result.decrypt(test_key) == -42

    def test_positive(self, test_key: SecretKey) -> None:
        """Test unary positive."""
        a = CipherInteger.encrypt(42, test_key)
        result = +a
        assert result.decrypt(test_key) == 42

    def test_abs(self, test_key: SecretKey) -> None:
        """Test absolute value."""
        a = CipherInteger.encrypt(-42, test_key)
        result = abs(a)
        assert result.decrypt(test_key) == 42

    def test_floor_division(self, test_key: SecretKey) -> None:
        """Test floor division."""
        a = CipherInteger.encrypt(43, test_key)
        b = CipherInteger.encrypt(5, test_key)
        result = a // b
        assert result.decrypt(test_key) == 8

    def test_modulo(self, test_key: SecretKey) -> None:
        """Test modulo operation."""
        a = CipherInteger.encrypt(43, test_key)
        b = CipherInteger.encrypt(5, test_key)
        result = a % b
        assert result.decrypt(test_key) == 3

    def test_division_by_zero(self, test_key: SecretKey) -> None:
        """Test that division by zero raises."""
        a = CipherInteger.encrypt(42, test_key)
        b = CipherInteger.encrypt(0, test_key)

        with pytest.raises(ZeroDivisionError):
            _ = a // b

        with pytest.raises(ZeroDivisionError):
            _ = a % b

    def test_different_keys_raise(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that operations with different keys raise ValueError."""
        a = CipherInteger.encrypt(10, test_key)
        b = CipherInteger.encrypt(5, alt_key)

        with pytest.raises(ValueError, match="different keys"):
            _ = a + b

        with pytest.raises(ValueError, match="different keys"):
            _ = a - b

        with pytest.raises(ValueError, match="different keys"):
            _ = a * b


class TestCipherIntegerComparisons:
    """Tests for encrypted comparison operations."""

    def test_cipher_eq(self, test_key: SecretKey) -> None:
        """Test encrypted equality comparison."""
        a = CipherInteger.encrypt(42, test_key)
        b = CipherInteger.encrypt(42, test_key)
        c = CipherInteger.encrypt(17, test_key)

        assert a.cipher_eq(b).decrypt(test_key) is True
        assert a.cipher_eq(c).decrypt(test_key) is False

    def test_cipher_ne(self, test_key: SecretKey) -> None:
        """Test encrypted inequality comparison."""
        a = CipherInteger.encrypt(42, test_key)
        b = CipherInteger.encrypt(42, test_key)
        c = CipherInteger.encrypt(17, test_key)

        assert a.cipher_ne(b).decrypt(test_key) is False
        assert a.cipher_ne(c).decrypt(test_key) is True

    def test_cipher_lt(self, test_key: SecretKey) -> None:
        """Test encrypted less-than comparison."""
        a = CipherInteger.encrypt(10, test_key)
        b = CipherInteger.encrypt(20, test_key)
        c = CipherInteger.encrypt(10, test_key)

        assert a.cipher_lt(b).decrypt(test_key) is True
        assert b.cipher_lt(a).decrypt(test_key) is False
        assert a.cipher_lt(c).decrypt(test_key) is False

    def test_cipher_le(self, test_key: SecretKey) -> None:
        """Test encrypted less-than-or-equal comparison."""
        a = CipherInteger.encrypt(10, test_key)
        b = CipherInteger.encrypt(20, test_key)
        c = CipherInteger.encrypt(10, test_key)

        assert a.cipher_le(b).decrypt(test_key) is True
        assert a.cipher_le(c).decrypt(test_key) is True
        assert b.cipher_le(a).decrypt(test_key) is False

    def test_cipher_gt(self, test_key: SecretKey) -> None:
        """Test encrypted greater-than comparison."""
        a = CipherInteger.encrypt(20, test_key)
        b = CipherInteger.encrypt(10, test_key)
        c = CipherInteger.encrypt(20, test_key)

        assert a.cipher_gt(b).decrypt(test_key) is True
        assert b.cipher_gt(a).decrypt(test_key) is False
        assert a.cipher_gt(c).decrypt(test_key) is False

    def test_cipher_ge(self, test_key: SecretKey) -> None:
        """Test encrypted greater-than-or-equal comparison."""
        a = CipherInteger.encrypt(20, test_key)
        b = CipherInteger.encrypt(10, test_key)
        c = CipherInteger.encrypt(20, test_key)

        assert a.cipher_ge(b).decrypt(test_key) is True
        assert a.cipher_ge(c).decrypt(test_key) is True
        assert b.cipher_ge(a).decrypt(test_key) is False


class TestCipherIntegerHomomorphism:
    """Tests verifying the homomorphic property for arithmetic."""

    def test_addition_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) + E(b)) == a + b."""
        test_cases = [(0, 0), (1, 1), (10, 20), (-5, 5), (-10, -20)]
        for a, b in test_cases:
            ea = CipherInteger.encrypt(a, test_key)
            eb = CipherInteger.encrypt(b, test_key)
            result = ea + eb
            assert result.decrypt(test_key) == a + b

    def test_subtraction_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) - E(b)) == a - b."""
        test_cases = [(0, 0), (10, 5), (5, 10), (-5, -10)]
        for a, b in test_cases:
            ea = CipherInteger.encrypt(a, test_key)
            eb = CipherInteger.encrypt(b, test_key)
            result = ea - eb
            assert result.decrypt(test_key) == a - b

    def test_multiplication_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) * E(b)) == a * b."""
        test_cases = [(0, 5), (1, 10), (2, 3), (-2, 3), (-2, -3)]
        for a, b in test_cases:
            ea = CipherInteger.encrypt(a, test_key)
            eb = CipherInteger.encrypt(b, test_key)
            result = ea * eb
            assert result.decrypt(test_key) == a * b

    def test_negation_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(-E(a)) == -a."""
        test_cases = [0, 1, -1, 42, -42]
        for a in test_cases:
            ea = CipherInteger.encrypt(a, test_key)
            result = -ea
            assert result.decrypt(test_key) == -a
