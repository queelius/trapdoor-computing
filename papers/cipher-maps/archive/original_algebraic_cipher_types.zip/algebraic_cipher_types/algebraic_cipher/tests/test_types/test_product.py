"""Tests for product types (CipherPair, CipherTuple)."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.product import CipherPair, CipherTuple, make_cipher_pair


class TestCipherPair:
    """Tests for CipherPair class."""

    def test_encrypt_decrypt(self, test_key: SecretKey) -> None:
        """Test basic encryption and decryption."""
        pair = CipherPair.encrypt((42, "hello"), test_key)
        result = pair.decrypt(test_key)
        assert result == (42, "hello")

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        pair = CipherPair.encrypt((1, 2), test_key)
        result = pair.decrypt(alt_key)
        assert result is None

    def test_encrypt_non_pair_raises(self, test_key: SecretKey) -> None:
        """Test that encrypting non-tuple raises TypeError."""
        with pytest.raises(TypeError, match="Expected tuple"):
            CipherPair.encrypt([1, 2], test_key)  # type: ignore

        with pytest.raises(TypeError, match="Expected tuple"):
            CipherPair.encrypt((1, 2, 3), test_key)  # type: ignore

    def test_first_projection(self, test_key: SecretKey) -> None:
        """Test first component projection."""
        pair = CipherPair.encrypt((42, "hello"), test_key)
        first = pair.first(test_key)
        assert first == 42

    def test_second_projection(self, test_key: SecretKey) -> None:
        """Test second component projection."""
        pair = CipherPair.encrypt((42, "hello"), test_key)
        second = pair.second(test_key)
        assert second == "hello"

    def test_swap(self, test_key: SecretKey) -> None:
        """Test swapping components."""
        pair = CipherPair.encrypt((1, 2), test_key)
        swapped = pair.swap()
        result = swapped.decrypt(test_key)
        assert result == (2, 1)

    def test_bimap(self, test_key: SecretKey) -> None:
        """Test bimap operation."""
        pair = CipherPair.encrypt((5, 10), test_key)
        mapped = pair.bimap(lambda x: x * 2, lambda y: y + 1)
        result = mapped.decrypt(test_key)
        assert result == (10, 11)

    def test_map_first(self, test_key: SecretKey) -> None:
        """Test map_first operation."""
        pair = CipherPair.encrypt((5, 10), test_key)
        mapped = pair.map_first(lambda x: x * 2)
        result = mapped.decrypt(test_key)
        assert result == (10, 10)

    def test_map_second(self, test_key: SecretKey) -> None:
        """Test map_second operation."""
        pair = CipherPair.encrypt((5, 10), test_key)
        mapped = pair.map_second(lambda y: y + 1)
        result = mapped.decrypt(test_key)
        assert result == (5, 11)

    def test_is_valid(self, test_key: SecretKey) -> None:
        """Test is_valid method."""
        valid = CipherPair.encrypt((1, 2), test_key)
        assert valid.is_valid()

        invalid = CipherPair()
        assert not invalid.is_valid()

    def test_make_cipher_pair_helper(self, test_key: SecretKey) -> None:
        """Test make_cipher_pair convenience function."""
        pair = make_cipher_pair(1, 2, key=test_key)
        result = pair.decrypt(test_key)
        assert result == (1, 2)


class TestCipherTuple:
    """Tests for CipherTuple class."""

    def test_encrypt_decrypt_empty(self, test_key: SecretKey) -> None:
        """Test encryption of empty tuple."""
        ct = CipherTuple.encrypt((), test_key)
        result = ct.decrypt(test_key)
        assert result == ()

    def test_encrypt_decrypt_single(self, test_key: SecretKey) -> None:
        """Test encryption of single-element tuple."""
        ct = CipherTuple.encrypt((42,), test_key)
        result = ct.decrypt(test_key)
        assert result == (42,)

    def test_encrypt_decrypt_multiple(self, test_key: SecretKey) -> None:
        """Test encryption of multi-element tuple."""
        ct = CipherTuple.encrypt((1, "hello", True, 3.14), test_key)
        result = ct.decrypt(test_key)
        assert result == (1, "hello", True, 3.14)

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)
        result = ct.decrypt(alt_key)
        assert result is None

    def test_encrypt_non_tuple_raises(self, test_key: SecretKey) -> None:
        """Test that encrypting non-tuple raises TypeError."""
        with pytest.raises(TypeError, match="Expected tuple"):
            CipherTuple.encrypt([1, 2, 3], test_key)  # type: ignore

    def test_length(self, test_key: SecretKey) -> None:
        """Test length method."""
        ct0 = CipherTuple.encrypt((), test_key)
        ct3 = CipherTuple.encrypt((1, 2, 3), test_key)

        assert ct0.length() == 0
        assert ct3.length() == 3

    def test_get(self, test_key: SecretKey) -> None:
        """Test element access by index."""
        ct = CipherTuple.encrypt((10, 20, 30), test_key)

        assert ct.get(0, test_key) == 10
        assert ct.get(1, test_key) == 20
        assert ct.get(2, test_key) == 30

    def test_get_out_of_range(self, test_key: SecretKey) -> None:
        """Test that out of range index raises."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)

        with pytest.raises(IndexError):
            ct.get(3, test_key)

        with pytest.raises(IndexError):
            ct.get(-1, test_key)

    def test_map(self, test_key: SecretKey) -> None:
        """Test map operation."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)
        mapped = ct.map(lambda x: x * 2)
        result = mapped.decrypt(test_key)
        assert result == (2, 4, 6)

    def test_map_at(self, test_key: SecretKey) -> None:
        """Test map_at operation."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)
        mapped = ct.map_at(1, lambda x: x * 10)
        result = mapped.decrypt(test_key)
        assert result == (1, 20, 3)

    def test_map_at_out_of_range(self, test_key: SecretKey) -> None:
        """Test that map_at with invalid index raises."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)

        with pytest.raises(IndexError):
            ct.map_at(5, lambda x: x)

    def test_to_pair(self, test_key: SecretKey) -> None:
        """Test conversion to CipherPair."""
        ct = CipherTuple.encrypt((1, 2), test_key)
        pair = ct.to_pair()
        result = pair.decrypt(test_key)
        assert result == (1, 2)

    def test_to_pair_wrong_length(self, test_key: SecretKey) -> None:
        """Test that to_pair with non-2-tuple raises."""
        ct = CipherTuple.encrypt((1, 2, 3), test_key)

        with pytest.raises(ValueError, match="2-tuples"):
            ct.to_pair()

    def test_is_valid(self, test_key: SecretKey) -> None:
        """Test is_valid method."""
        valid = CipherTuple.encrypt((1, 2, 3), test_key)
        assert valid.is_valid()

        invalid = CipherTuple()
        assert not invalid.is_valid()
