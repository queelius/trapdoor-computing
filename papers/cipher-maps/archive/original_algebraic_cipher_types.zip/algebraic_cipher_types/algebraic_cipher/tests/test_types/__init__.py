"""Tests for cipher types."""
