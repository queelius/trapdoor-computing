"""Tests for CipherBool."""

import pytest
from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.types.boolean import CipherBool


class TestCipherBoolBasic:
    """Basic tests for CipherBool."""

    def test_encrypt_decrypt_true(self, test_key: SecretKey) -> None:
        """Test encryption and decryption of True."""
        cipher = CipherBool.encrypt(True, test_key)
        result = cipher.decrypt(test_key)
        assert result is True

    def test_encrypt_decrypt_false(self, test_key: SecretKey) -> None:
        """Test encryption and decryption of False."""
        cipher = CipherBool.encrypt(False, test_key)
        result = cipher.decrypt(test_key)
        assert result is False

    def test_wrong_key_returns_none(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that wrong key returns None."""
        cipher = CipherBool.encrypt(True, test_key)
        result = cipher.decrypt(alt_key)
        assert result is None

    def test_encrypt_non_bool_raises(self, test_key: SecretKey) -> None:
        """Test that encrypting non-bool raises TypeError."""
        with pytest.raises(TypeError, match="Expected bool"):
            CipherBool.encrypt(1, test_key)  # type: ignore

        with pytest.raises(TypeError, match="Expected bool"):
            CipherBool.encrypt("true", test_key)  # type: ignore

    def test_is_valid(self, test_key: SecretKey) -> None:
        """Test is_valid method."""
        valid_cipher = CipherBool.encrypt(True, test_key)
        assert valid_cipher.is_valid()

        invalid_cipher = CipherBool()
        assert not invalid_cipher.is_valid()

    def test_factory_methods(self, test_key: SecretKey) -> None:
        """Test true_ and false_ factory methods."""
        true_cipher = CipherBool.true_(test_key)
        false_cipher = CipherBool.false_(test_key)

        assert true_cipher.decrypt(test_key) is True
        assert false_cipher.decrypt(test_key) is False


class TestCipherBoolLogicalOps:
    """Tests for homomorphic logical operations."""

    def test_and_true_true(self, test_key: SecretKey) -> None:
        """Test True AND True = True."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(True, test_key)
        result = a & b
        assert result.decrypt(test_key) is True

    def test_and_true_false(self, test_key: SecretKey) -> None:
        """Test True AND False = False."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a & b
        assert result.decrypt(test_key) is False

    def test_and_false_false(self, test_key: SecretKey) -> None:
        """Test False AND False = False."""
        a = CipherBool.encrypt(False, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a & b
        assert result.decrypt(test_key) is False

    def test_or_true_true(self, test_key: SecretKey) -> None:
        """Test True OR True = True."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(True, test_key)
        result = a | b
        assert result.decrypt(test_key) is True

    def test_or_true_false(self, test_key: SecretKey) -> None:
        """Test True OR False = True."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a | b
        assert result.decrypt(test_key) is True

    def test_or_false_false(self, test_key: SecretKey) -> None:
        """Test False OR False = False."""
        a = CipherBool.encrypt(False, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a | b
        assert result.decrypt(test_key) is False

    def test_not_true(self, test_key: SecretKey) -> None:
        """Test NOT True = False."""
        a = CipherBool.encrypt(True, test_key)
        result = ~a
        assert result.decrypt(test_key) is False

    def test_not_false(self, test_key: SecretKey) -> None:
        """Test NOT False = True."""
        a = CipherBool.encrypt(False, test_key)
        result = ~a
        assert result.decrypt(test_key) is True

    def test_xor_same(self, test_key: SecretKey) -> None:
        """Test XOR of same values = False."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(True, test_key)
        result = a ^ b
        assert result.decrypt(test_key) is False

        a = CipherBool.encrypt(False, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a ^ b
        assert result.decrypt(test_key) is False

    def test_xor_different(self, test_key: SecretKey) -> None:
        """Test XOR of different values = True."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(False, test_key)
        result = a ^ b
        assert result.decrypt(test_key) is True

    def test_different_keys_raise(
        self, test_key: SecretKey, alt_key: SecretKey
    ) -> None:
        """Test that operations with different keys raise ValueError."""
        a = CipherBool.encrypt(True, test_key)
        b = CipherBool.encrypt(True, alt_key)

        with pytest.raises(ValueError, match="different keys"):
            _ = a & b

        with pytest.raises(ValueError, match="different keys"):
            _ = a | b

        with pytest.raises(ValueError, match="different keys"):
            _ = a ^ b


class TestCipherBoolHomomorphism:
    """Tests verifying the homomorphic property."""

    def test_and_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) & E(b)) == a and b."""
        for a in [True, False]:
            for b in [True, False]:
                ea = CipherBool.encrypt(a, test_key)
                eb = CipherBool.encrypt(b, test_key)
                result = ea & eb
                assert result.decrypt(test_key) == (a and b)

    def test_or_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) | E(b)) == a or b."""
        for a in [True, False]:
            for b in [True, False]:
                ea = CipherBool.encrypt(a, test_key)
                eb = CipherBool.encrypt(b, test_key)
                result = ea | eb
                assert result.decrypt(test_key) == (a or b)

    def test_not_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(~E(a)) == not a."""
        for a in [True, False]:
            ea = CipherBool.encrypt(a, test_key)
            result = ~ea
            assert result.decrypt(test_key) == (not a)

    def test_xor_homomorphism(self, test_key: SecretKey) -> None:
        """Test decrypt(E(a) ^ E(b)) == a xor b."""
        for a in [True, False]:
            for b in [True, False]:
                ea = CipherBool.encrypt(a, test_key)
                eb = CipherBool.encrypt(b, test_key)
                result = ea ^ eb
                assert result.decrypt(test_key) == (a != b)
