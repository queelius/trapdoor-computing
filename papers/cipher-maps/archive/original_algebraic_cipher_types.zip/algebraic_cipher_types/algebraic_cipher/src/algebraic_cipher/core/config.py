"""Configuration parameters for cipher encoding.

This module defines configuration structures that control how plaintext
values are encoded into ciphertexts, affecting both security and performance.
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Final


class HashStrategy(Enum):
    """Strategy for hash function selection in cipher operations."""

    FAST = auto()
    """Fast hashing, potentially less secure. Suitable for non-critical operations."""

    SECURE = auto()
    """Cryptographically secure hashing. Use for sensitive data."""

    BALANCED = auto()
    """Balance between speed and security. Default choice."""


@dataclass(frozen=True, slots=True)
class EncodingConfig:
    """Configuration parameters for cipher encoding.

    This class encapsulates all configuration parameters that control
    how plaintext values are encoded into ciphertexts.

    Attributes:
        security_parameter: Bit strength of the encoding (128, 192, or 256)
        false_positive_rate: Probability of false positives in probabilistic ops
        false_negative_rate: Probability of false negatives (usually 0.0)
        use_randomization: Enable randomized encoding for semantic security
        hash_strategy: Strategy for hash function selection

    Example:
        >>> config = EncodingConfig(
        ...     security_parameter=256,
        ...     false_positive_rate=1e-15,
        ...     use_randomization=True
        ... )
    """

    security_parameter: int = 128
    """Security parameter in bits. Common values: 128 (standard), 192 (high), 256 (maximum)."""

    false_positive_rate: float = 1e-9
    """False positive rate for probabilistic operations. Lower values increase ciphertext size."""

    false_negative_rate: float = 0.0
    """False negative rate. Most operations have zero false negatives."""

    use_randomization: bool = False
    """Enable randomized encoding for semantic security. Same plaintext -> different ciphertexts."""

    hash_strategy: HashStrategy = HashStrategy.BALANCED
    """Strategy for hash function selection."""

    representation_index: int = 0
    """Which k-th representation to use (for multiple valid encodings)."""

    def __post_init__(self) -> None:
        """Validate configuration parameters."""
        if self.security_parameter not in (128, 192, 256):
            raise ValueError(
                f"security_parameter must be 128, 192, or 256, got {self.security_parameter}"
            )
        if not (0.0 <= self.false_positive_rate <= 1.0):
            raise ValueError(
                f"false_positive_rate must be in [0, 1], got {self.false_positive_rate}"
            )
        if not (0.0 <= self.false_negative_rate <= 1.0):
            raise ValueError(
                f"false_negative_rate must be in [0, 1], got {self.false_negative_rate}"
            )
        if self.representation_index < 0:
            raise ValueError(
                f"representation_index must be non-negative, got {self.representation_index}"
            )


# Default configuration for typical usage
DEFAULT_CONFIG: Final[EncodingConfig] = EncodingConfig()

# High-security configuration for sensitive data
HIGH_SECURITY_CONFIG: Final[EncodingConfig] = EncodingConfig(
    security_parameter=256,
    false_positive_rate=1e-15,
    use_randomization=True,
    hash_strategy=HashStrategy.SECURE,
)

# Performance-optimized configuration for non-critical operations
FAST_CONFIG: Final[EncodingConfig] = EncodingConfig(
    security_parameter=128,
    false_positive_rate=1e-6,
    use_randomization=False,
    hash_strategy=HashStrategy.FAST,
)
