"""Secret key implementation for cipher operations.

The SecretKey class provides secure key management with:
- Immutability via frozen dataclass
- Constant-time comparison to prevent timing attacks
- Secure string representation to prevent accidental logging
"""

from dataclasses import dataclass
from typing import Final
import secrets
import hashlib


@dataclass(frozen=True, slots=True)
class SecretKey:
    """Cryptographic key for encryption and decryption operations.

    This class implements secure key handling with:
    - Frozen dataclass for immutability (Python equivalent of move-only)
    - Constant-time comparison via secrets.compare_digest
    - Hidden repr to prevent accidental exposure in logs

    Example:
        >>> key = SecretKey("my-secure-key")
        >>> key2 = SecretKey("my-secure-key")
        >>> key == key2  # Uses constant-time comparison
        True
        >>> print(key)  # Safe for logging
        SecretKey(hash=a1b2c3...)

    Warning:
        Keys should be generated from cryptographically secure random sources.
        Never store keys in plain text or transmit over insecure channels.
    """

    _value: str

    def __post_init__(self) -> None:
        """Validate key on construction."""
        if not self._value:
            raise ValueError("Key cannot be empty")

    @property
    def value(self) -> str:
        """Access the underlying key value.

        Warning:
            Use with caution - avoid logging or displaying key values.
        """
        return self._value

    def __eq__(self, other: object) -> bool:
        """Constant-time comparison to prevent timing attacks."""
        if not isinstance(other, SecretKey):
            return NotImplemented
        return secrets.compare_digest(self._value, other._value)

    def __hash__(self) -> int:
        """Hash based on key value for use in dictionaries."""
        return hash(self._value)

    def __repr__(self) -> str:
        """Safe representation that doesn't expose the actual key."""
        key_hash = hashlib.sha256(self._value.encode()).hexdigest()[:16]
        return f"SecretKey(hash={key_hash}...)"

    def __str__(self) -> str:
        """Safe string representation."""
        return self.__repr__()

    def derive_subkey(self, purpose: str) -> "SecretKey":
        """Derive a subkey for a specific purpose using HKDF-like construction.

        This allows creating domain-separated keys from a master key.

        Args:
            purpose: A string identifying the purpose of the subkey

        Returns:
            A new SecretKey derived from this key and the purpose

        Example:
            >>> master = SecretKey("master-key")
            >>> encryption_key = master.derive_subkey("encryption")
            >>> signing_key = master.derive_subkey("signing")
        """
        combined = f"{self._value}:{purpose}"
        derived = hashlib.sha256(combined.encode()).hexdigest()
        return SecretKey(derived)

    @classmethod
    def generate(cls) -> "SecretKey":
        """Generate a new random secret key.

        Returns:
            A new SecretKey with 256 bits of entropy
        """
        return cls(secrets.token_hex(32))


# Sentinel for testing - a well-known key that should only be used in tests
_TEST_KEY: Final[SecretKey] = SecretKey("TEST-KEY-DO-NOT-USE-IN-PRODUCTION")
