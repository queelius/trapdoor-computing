"""Domain class for cipher function input ranges.

The domain represents the valid input range for a cipher function.
It supports both finite discrete domains and range-based continuous domains.
"""

from dataclasses import dataclass, field
from typing import TypeVar, Generic, Iterable, Iterator, Sequence
from collections.abc import Container


T = TypeVar("T")


@dataclass(slots=True)
class Domain(Generic[T], Container[T], Iterable[T]):
    """Represents the input domain for a cipher function.

    A domain can be:
    - Discrete: Explicit enumeration of values
    - Range-based: For integers, specified by min/max bounds

    Example:
        >>> # Discrete domain from explicit values
        >>> dom = Domain.from_values([1, 2, 3, 4, 5])
        >>> 3 in dom
        True

        >>> # Range domain for integers
        >>> dom = Domain.from_range(0, 100)
        >>> 50 in dom
        True

        >>> # Boolean domain
        >>> dom = Domain.boolean()
        >>> True in dom
        True
    """

    _values: tuple[T, ...] = field(default_factory=tuple)
    _min: T | None = field(default=None, repr=False)
    _max: T | None = field(default=None, repr=False)
    _is_discrete: bool = field(default=True)

    @classmethod
    def from_values(cls, values: Iterable[T]) -> "Domain[T]":
        """Create a domain from explicit values.

        Args:
            values: Iterable of domain values

        Returns:
            Discrete domain containing the given values
        """
        # Remove duplicates while preserving order
        seen: set[T] = set()
        unique_values: list[T] = []
        for v in values:
            if v not in seen:
                seen.add(v)
                unique_values.append(v)

        # Sort if possible (may fail for non-comparable types)
        try:
            unique_values.sort()
        except TypeError:
            pass  # Not comparable, keep original order

        return cls(_values=tuple(unique_values), _is_discrete=True)

    @classmethod
    def from_range(cls, min_val: int, max_val: int, max_enumerate: int = 1000) -> "Domain[int]":
        """Create a domain from an integer range [min_val, max_val].

        Args:
            min_val: Minimum value (inclusive)
            max_val: Maximum value (inclusive)
            max_enumerate: Maximum range size to enumerate explicitly

        Returns:
            Range domain or discrete domain if small enough
        """
        if max_val < min_val:
            raise ValueError(f"max_val ({max_val}) must be >= min_val ({min_val})")

        size = max_val - min_val + 1
        if size <= max_enumerate:
            # Small enough to enumerate
            values = tuple(range(min_val, max_val + 1))
            return cls(_values=values, _min=min_val, _max=max_val, _is_discrete=True)  # type: ignore
        else:
            # Keep as range
            return cls(_min=min_val, _max=max_val, _is_discrete=False)  # type: ignore

    @classmethod
    def boolean(cls) -> "Domain[bool]":
        """Create the boolean domain {False, True}."""
        return cls(_values=(False, True), _is_discrete=True)  # type: ignore

    @classmethod
    def singleton(cls, value: T) -> "Domain[T]":
        """Create a domain with a single value."""
        return cls(_values=(value,), _is_discrete=True)

    @classmethod
    def empty(cls) -> "Domain[T]":
        """Create an empty domain."""
        return cls(_values=(), _is_discrete=True)

    def __len__(self) -> int:
        """Return the size of the domain."""
        if self._is_discrete:
            return len(self._values)
        elif self._min is not None and self._max is not None:
            return int(self._max) - int(self._min) + 1  # type: ignore
        return 0

    def __contains__(self, item: object) -> bool:
        """Check if an item is in the domain."""
        if self._is_discrete:
            return item in self._values
        elif self._min is not None and self._max is not None:
            return self._min <= item <= self._max  # type: ignore
        return False

    def __iter__(self) -> Iterator[T]:
        """Iterate over domain values."""
        if self._is_discrete:
            return iter(self._values)
        elif self._min is not None and self._max is not None:
            return iter(range(int(self._min), int(self._max) + 1))  # type: ignore
        return iter(())

    @property
    def values(self) -> tuple[T, ...]:
        """Get all values in the domain (for discrete domains).

        Raises:
            ValueError: If domain is not discrete and too large to enumerate
        """
        if self._is_discrete:
            return self._values
        elif self._min is not None and self._max is not None:
            size = int(self._max) - int(self._min) + 1  # type: ignore
            if size <= 10000:
                return tuple(range(int(self._min), int(self._max) + 1))  # type: ignore
            raise ValueError(f"Domain too large to enumerate ({size} elements)")
        return ()

    @property
    def is_discrete(self) -> bool:
        """Check if domain is discrete (enumerable)."""
        return self._is_discrete

    @property
    def min(self) -> T | None:
        """Get minimum value (for range domains or sorted discrete domains)."""
        if self._min is not None:
            return self._min
        if self._values:
            return self._values[0]
        return None

    @property
    def max(self) -> T | None:
        """Get maximum value (for range domains or sorted discrete domains)."""
        if self._max is not None:
            return self._max
        if self._values:
            return self._values[-1]
        return None

    def is_empty(self) -> bool:
        """Check if domain is empty."""
        return len(self) == 0

    def union(self, other: "Domain[T]") -> "Domain[T]":
        """Create union of two domains.

        Args:
            other: Another domain

        Returns:
            Domain containing values from both domains
        """
        if self._is_discrete and other._is_discrete:
            combined = set(self._values) | set(other._values)
            return Domain.from_values(combined)

        # For range domains, we need to be more careful
        # For simplicity, convert to discrete if possible
        try:
            combined = set(self) | set(other)
            return Domain.from_values(combined)
        except (TypeError, MemoryError):
            raise ValueError("Cannot create union of large non-discrete domains")

    def intersection(self, other: "Domain[T]") -> "Domain[T]":
        """Create intersection of two domains.

        Args:
            other: Another domain

        Returns:
            Domain containing values in both domains
        """
        if self._is_discrete and other._is_discrete:
            combined = set(self._values) & set(other._values)
            return Domain.from_values(combined)

        # For range domains
        try:
            combined = set(self) & set(other)
            return Domain.from_values(combined)
        except (TypeError, MemoryError):
            raise ValueError("Cannot create intersection of large non-discrete domains")

    def map(self, f: "Callable[[T], U]") -> "Domain[U]":
        """Map a function over the domain.

        Args:
            f: Function to apply to each element

        Returns:
            New domain with transformed elements
        """
        if not self._is_discrete:
            raise ValueError("Cannot map over non-discrete domain")
        return Domain.from_values(f(v) for v in self._values)


from typing import Callable, TypeVar as TV

U = TV("U")
