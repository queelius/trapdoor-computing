"""Bernoulli types module - probabilistic approximation with controlled error rates.

This module implements the theoretical framework from the Bernoulli Types paper series,
providing the connection between algebraic cipher types and probabilistic data structures
with explicit error rate modeling.

Key Concepts:
- Latent/Observed Duality: Every value exists in two forms
  - Latent: The true mathematical value (hidden)
  - Observed: The noisy/encrypted approximation (visible)

- Confusion Matrix: Defines the error characteristics
  [[1-α, α], [β, 1-β]]
  where α = false positive rate, β = false negative rate

- Error Propagation: Tracks how error rates compose through operations

Example:
    >>> from algebraic_cipher.bernoulli import ConfusionMatrix, BernoulliBoolean
    >>>
    >>> # Binary Symmetric Channel (first-order, symmetric errors)
    >>> bsc = ConfusionMatrix.symmetric(p=0.1)
    >>>
    >>> # Binary Asymmetric Channel (second-order, distinct α and β)
    >>> bac = ConfusionMatrix(alpha=0.05, beta=0.1)
"""

from algebraic_cipher.bernoulli.confusion import ConfusionMatrix, ErrorRateSpan
from algebraic_cipher.bernoulli.bernoulli_bool import (
    BernoulliBoolean,
    bsc_channel,
    bac_channel,
    z_channel,
)
from algebraic_cipher.bernoulli.propagation import (
    propagate_and,
    propagate_or,
    propagate_not,
    compose_matrices,
)

__all__ = [
    # Core types
    "ConfusionMatrix",
    "ErrorRateSpan",
    "BernoulliBoolean",
    # Channel constructors
    "bsc_channel",
    "bac_channel",
    "z_channel",
    # Propagation
    "propagate_and",
    "propagate_or",
    "propagate_not",
    "compose_matrices",
]
