"""Unit type - the simplest algebraic type with exactly one value.

The unit type serves as:
- The identity element for product types: A × unit ≅ A
- The terminal object in the category of types
- A placeholder representing "no information" in a type-safe way
"""

from dataclasses import dataclass, field
from typing import ClassVar
import hashlib

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG


class Unit:
    """Unit type representing a single canonical value.

    There is exactly one instance of Unit, making it a singleton type.
    All Unit values are equal to each other.

    Mathematical Properties:
    - Exactly one inhabitant (singleton type)
    - Identity for products: A × Unit ≅ A
    - Terminal object in the category of types

    Example:
        >>> u1 = Unit()
        >>> u2 = Unit()
        >>> u1 == u2
        True
    """

    _instance: ClassVar["Unit | None"] = None

    def __new__(cls) -> "Unit":
        """Ensure only one Unit instance exists (singleton pattern)."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __eq__(self, other: object) -> bool:
        """All units are equal."""
        return isinstance(other, Unit)

    def __hash__(self) -> int:
        """Constant hash for the unique unit value."""
        return hash("Unit")

    def __repr__(self) -> str:
        return "Unit()"

    def __str__(self) -> str:
        return "()"


# Global constant for the unique unit value
UNIT = Unit()


@dataclass(slots=True)
class CipherUnit:
    """Encrypted unit type.

    Even though unit contains no information, the cipher provides:
    - Key verification (wrong key returns None)
    - Authentication (detecting tampering)
    - Uniform interface with other cipher types

    Example:
        >>> key = SecretKey("my-key")
        >>> cipher_unit = CipherUnit.encrypt(Unit(), key)
        >>> cipher_unit.decrypt(key)
        Unit()
        >>> cipher_unit.decrypt(SecretKey("wrong-key"))
        None
    """

    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)

    @classmethod
    def encrypt(
        cls, value: Unit, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherUnit":
        """Encrypt a unit value.

        Args:
            value: The unit value (always Unit())
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher unit
        """
        if not isinstance(value, Unit):
            raise TypeError(f"Expected Unit, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()
        return cls(_key_hash=key_hash, _config=cfg)

    def decrypt(self, key: SecretKey) -> Unit | None:
        """Decrypt to retrieve the unit value.

        Args:
            key: Secret key for decryption

        Returns:
            Unit() if key is correct, None otherwise
        """
        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if provided_hash == self._key_hash:
            return UNIT
        return None

    def is_valid(self) -> bool:
        """Check if this cipher is valid."""
        return self._key_hash != ""

    @property
    def false_positive_rate(self) -> float:
        """Unit has zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Unit has zero false negative rate."""
        return 0.0
