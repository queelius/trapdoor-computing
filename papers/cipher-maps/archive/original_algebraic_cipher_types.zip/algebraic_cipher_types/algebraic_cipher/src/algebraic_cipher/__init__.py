"""
Algebraic Cipher Types - A Python library for homomorphic encryption.

This library provides a type-safe framework for secure computation through
homomorphic operations on encrypted algebraic structures.

Mathematical Foundation:
The cipher functor lifts a monoid (S, *) to an encrypted monoid c_A(S, *) where:
- S is the underlying algebraic structure
- A is the encoding set
- The homomorphic property preserves: decrypt(op(encrypt(a), encrypt(b))) = op(a, b)

Example:
    >>> from algebraic_cipher import SecretKey, CipherBool
    >>> key = SecretKey("my-secure-key")
    >>> a = CipherBool.encrypt(True, key)
    >>> b = CipherBool.encrypt(False, key)
    >>> result = a & b  # Homomorphic AND
    >>> result.decrypt(key)  # Returns False
"""

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig
from algebraic_cipher.core.protocols import CipherType, Functor, Monad
from algebraic_cipher.types.unit import Unit, CipherUnit
from algebraic_cipher.types.boolean import CipherBool
from algebraic_cipher.types.integer import CipherInteger
from algebraic_cipher.types.product import CipherPair, CipherTuple
from algebraic_cipher.types.sum import Either, CipherEither, CipherOptional
from algebraic_cipher.functions.domain import Domain
from algebraic_cipher.functions.cipher_function import CipherFunction
from algebraic_cipher.functions.combinators import identity, constant, compose, product, curry

__version__ = "0.1.0"

__all__ = [
    # Core
    "SecretKey",
    "EncodingConfig",
    "CipherType",
    "Functor",
    "Monad",
    # Types
    "Unit",
    "CipherUnit",
    "CipherBool",
    "CipherInteger",
    "CipherPair",
    "CipherTuple",
    "Either",
    "CipherEither",
    "CipherOptional",
    # Functions
    "Domain",
    "CipherFunction",
    "identity",
    "constant",
    "compose",
    "product",
    "curry",
]
