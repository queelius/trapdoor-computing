"""Cipher function - homomorphic function evaluation on encrypted values.

For a function f: X -> Y, we construct cipher_f: Cipher[X] -> Cipher[Y] such that:
    decrypt(cipher_f(encrypt(x))) = f(x)

This preserves the function semantics while operating on encrypted values.
"""

from dataclasses import dataclass, field
from typing import TypeVar, Generic, Callable, Any, Hashable
import time
import secrets
import hashlib

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG
from algebraic_cipher.functions.domain import Domain
from algebraic_cipher.functions.impl import FunctionTable, Statistics, select_bin_count


X = TypeVar("X", bound=Hashable)
Y = TypeVar("Y", bound=Hashable)


@dataclass(frozen=True, slots=True)
class FunctionConfig:
    """Configuration for cipher function construction.

    Attributes:
        num_bins: Number of bins for domain partitioning (0=auto-select)
        max_seed_attempts: Maximum attempts for seed finding
        seed: Random seed for deterministic construction
        enable_cache: Enable caching of computed results
        optimization_level: 0=size, 1=balanced, 2=speed
    """

    num_bins: int = 0
    max_seed_attempts: int = 1000
    seed: int | None = None
    enable_cache: bool = True
    optimization_level: int = 1


# Default function configuration
DEFAULT_FUNCTION_CONFIG = FunctionConfig()


@dataclass
class CipherFunction(Generic[X, Y]):
    """Homomorphic function evaluation on encrypted values.

    Implements the two-stage algorithm for constructing functions that
    operate on encrypted values while preserving encryption.

    Example:
        >>> key = SecretKey("my-key")
        >>> square = CipherFunction.from_function(
        ...     lambda x: x * x,
        ...     Domain.from_range(0, 100)
        ... )
        >>> encrypted_5 = CipherInteger.encrypt(5, key)
        >>> result = square.apply(encrypted_5, key)
        >>> result.decrypt(key)
        25
    """

    _func: Callable[[X], Y] = field(repr=False)
    _domain: Domain[X] = field(repr=False)
    _table: FunctionTable[X, Y] | None = field(default=None, repr=False)
    _config: FunctionConfig = field(default_factory=lambda: DEFAULT_FUNCTION_CONFIG)
    _cache: dict[X, Y] = field(default_factory=dict, repr=False)
    _cache_hits: int = field(default=0, repr=False)
    _cache_misses: int = field(default=0, repr=False)

    @classmethod
    def from_function(
        cls,
        f: Callable[[X], Y],
        domain: Domain[X],
        config: FunctionConfig | None = None,
    ) -> "CipherFunction[X, Y]":
        """Create a cipher function from a plain function.

        Args:
            f: The function f: X -> Y
            domain: The input domain
            config: Optional function configuration

        Returns:
            Cipher function ready for homomorphic evaluation
        """
        cfg = config or DEFAULT_FUNCTION_CONFIG

        # Determine seed
        if cfg.seed is not None:
            seed = cfg.seed
        else:
            seed = int(time.time() * 1000000) ^ secrets.randbits(32)

        # Determine number of bins
        num_bins = cfg.num_bins
        if num_bins == 0:
            num_bins = select_bin_count(len(domain), cfg.optimization_level)

        # Build function table
        table = FunctionTable.build(
            f=f,
            domain=domain,
            num_bins=num_bins,
            seed=seed,
            max_seed_attempts=cfg.max_seed_attempts,
        )

        return cls(_func=f, _domain=domain, _table=table, _config=cfg)

    def __call__(self, x: X) -> Y:
        """Evaluate the function on a plain value.

        Args:
            x: Input value

        Returns:
            Function output
        """
        return self._func(x)

    def apply(
        self,
        encrypted_input: Any,
        key: SecretKey,
        config: EncodingConfig | None = None,
    ) -> Any:
        """Apply function to an encrypted value.

        Args:
            encrypted_input: Encrypted input value
            key: Secret key for decryption/re-encryption
            config: Optional encoding configuration

        Returns:
            Encrypted output value
        """
        # Decrypt input
        x = encrypted_input.decrypt(key)
        if x is None:
            raise ValueError("Failed to decrypt input")

        # Check cache if enabled
        y: Y
        if self._config.enable_cache and x in self._cache:
            self._cache_hits += 1
            y = self._cache[x]
        else:
            self._cache_misses += 1

            # Look up in table
            if self._table is not None:
                lookup_result = self._table.lookup(x)
                if lookup_result is None:
                    raise ValueError(f"Input {x} not in function domain")
                y = lookup_result
            else:
                # Fallback to direct evaluation
                y = self._func(x)

            # Cache result
            if self._config.enable_cache:
                self._cache[x] = y

        # Re-encrypt result
        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        # Create appropriate cipher type for the output
        # This is a simplified approach - in practice we'd need
        # type-specific handling
        from algebraic_cipher.types.integer import CipherInteger
        from algebraic_cipher.types.boolean import CipherBool

        if isinstance(y, bool):
            return CipherBool.encrypt(y, key, cfg)
        elif isinstance(y, int):
            return CipherInteger.encrypt(y, key, cfg)
        else:
            # Generic fallback - would need extension for other types
            raise TypeError(f"Unsupported output type: {type(y)}")

    @property
    def domain(self) -> Domain[X]:
        """Get the input domain."""
        return self._domain

    def get_statistics(self) -> Statistics:
        """Get statistics about the function."""
        if self._table is None:
            return Statistics()

        return Statistics(
            domain_size=self._table.domain_size,
            num_bins=self._table.num_bins,
            total_seeds=self._table.total_seeds,
            average_seeds_per_bin=(
                self._table.total_seeds / self._table.num_bins
                if self._table.num_bins > 0
                else 0.0
            ),
            cache_hits=self._cache_hits,
            cache_misses=self._cache_misses,
        )

    def is_valid(self) -> bool:
        """Check if the function is valid."""
        return self._table is not None


@dataclass
class CipherFunctionBuilder(Generic[X, Y]):
    """Builder for creating cipher functions with fluent API.

    Example:
        >>> fn = (CipherFunctionBuilder[int, int]()
        ...     .with_function(lambda x: x * 2)
        ...     .with_domain(Domain.from_range(0, 100))
        ...     .with_config(FunctionConfig(optimization_level=2))
        ...     .build())
    """

    _func: Callable[[X], Y] | None = None
    _domain: Domain[X] | None = None
    _config: FunctionConfig = field(default_factory=lambda: DEFAULT_FUNCTION_CONFIG)

    def with_function(self, f: Callable[[X], Y]) -> "CipherFunctionBuilder[X, Y]":
        """Set the function to evaluate."""
        self._func = f
        return self

    def with_domain(self, domain: Domain[X]) -> "CipherFunctionBuilder[X, Y]":
        """Set the input domain."""
        self._domain = domain
        return self

    def with_config(self, config: FunctionConfig) -> "CipherFunctionBuilder[X, Y]":
        """Set the function configuration."""
        self._config = config
        return self

    def build(self) -> CipherFunction[X, Y]:
        """Build the cipher function.

        Raises:
            ValueError: If function or domain not set
        """
        if self._func is None:
            raise ValueError("Function not set")
        if self._domain is None:
            raise ValueError("Domain not set")

        return CipherFunction.from_function(self._func, self._domain, self._config)
