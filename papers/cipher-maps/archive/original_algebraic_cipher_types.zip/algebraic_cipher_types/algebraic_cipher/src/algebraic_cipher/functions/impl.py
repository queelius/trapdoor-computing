"""Implementation details for the two-stage cipher function algorithm.

Stage 1 (Domain Partitioning):
- Divide domain into bins based on size heuristics
- Each bin gets a unique hash-based identifier

Stage 2 (Seed Finding):
- For each bin, find seeds that hash to correct outputs
- Use multiple strategies: random, systematic, fallback
"""

from dataclasses import dataclass, field
from typing import TypeVar, Generic, Callable, Hashable
import hashlib
import random
import math

from algebraic_cipher.functions.domain import Domain


X = TypeVar("X", bound=Hashable)
Y = TypeVar("Y", bound=Hashable)


def hash_combine(seed: int, value: int) -> int:
    """Combine two hash values using boost's hash_combine algorithm."""
    return seed ^ (value + 0x9E3779B9 + (seed << 6) + (seed >> 2))


def compute_hash(value: X, seed: int) -> int:
    """Compute a seeded hash of a value."""
    h1 = hash(value)
    h2 = hash(seed)
    return hash_combine(h1, h2)


def select_bin_count(domain_size: int, optimization_level: int = 1) -> int:
    """Select optimal number of bins based on domain size.

    Args:
        domain_size: Size of the input domain
        optimization_level: 0=size, 1=balanced, 2=speed

    Returns:
        Recommended number of bins
    """
    # Heuristic: sqrt(domain_size) with bounds based on optimization
    optimal = int(math.sqrt(domain_size))

    max_bins = {0: 64, 1: 256, 2: 1024}.get(optimization_level, 256)
    optimal = min(optimal, max_bins)

    return max(1, optimal)


@dataclass
class BinPartitioner(Generic[X]):
    """Assigns domain elements to bins for efficient lookup."""

    num_bins: int
    seed: int

    def get_bin(self, value: X) -> int:
        """Get the bin index for a value."""
        return compute_hash(value, self.seed) % self.num_bins


@dataclass
class SeedFinder(Generic[Y]):
    """Finds seeds that map to target outputs."""

    base_seed: int
    max_attempts: int = 1000

    def find_seeds(self, targets: set[Y]) -> dict[Y, int]:
        """Find seeds that produce the target outputs.

        Args:
            targets: Set of desired output values

        Returns:
            Mapping from outputs to seeds that produce them
        """
        result: dict[Y, int] = {}
        rng = random.Random(self.base_seed)

        # Strategy 1: Random search
        for _ in range(self.max_attempts // 2):
            seed = rng.randint(0, 2**63 - 1)
            for target in targets:
                if target not in result:
                    if self._verify_seed(seed, target):
                        result[target] = seed
                        if len(result) == len(targets):
                            return result

        # Strategy 2: Systematic search
        systematic_seed = self.base_seed
        for _ in range(self.max_attempts // 2):
            systematic_seed = self._next_systematic_seed(systematic_seed)
            for target in targets:
                if target not in result:
                    if self._verify_seed(systematic_seed, target):
                        result[target] = systematic_seed

        # Strategy 3: Fallback - deterministic mapping
        for target in targets:
            if target not in result:
                result[target] = self._fallback_seed(target)

        return result

    def _verify_seed(self, seed: int, target: Y) -> bool:
        """Verify if a seed maps correctly to a target.

        In a real FHE implementation, this would check if
        decode(hash(input || seed)) == target.
        """
        # Simplified probabilistic check
        h = compute_hash(target, seed)
        return (h % 100) < 30  # 30% success rate simulation

    def _next_systematic_seed(self, current: int) -> int:
        """Generate next seed in systematic search."""
        # Linear congruential generator
        return (current * 1664525 + 1013904223) & ((1 << 63) - 1)

    def _fallback_seed(self, target: Y) -> int:
        """Deterministic fallback seed based on target."""
        return hash(target) ^ self.base_seed


@dataclass
class FunctionTable(Generic[X, Y]):
    """Lookup table for function evaluation.

    Stores precomputed function values organized by bins for efficient
    homomorphic evaluation.
    """

    _mappings: dict[X, Y] = field(default_factory=dict)
    _bin_mappings: dict[int, dict[X, Y]] = field(default_factory=dict)
    _bin_seeds: dict[int, dict[Y, int]] = field(default_factory=dict)
    _partitioner: BinPartitioner[X] | None = None

    @classmethod
    def build(
        cls,
        f: Callable[[X], Y],
        domain: Domain[X],
        num_bins: int,
        seed: int,
        max_seed_attempts: int = 1000,
    ) -> "FunctionTable[X, Y]":
        """Build a function table using the two-stage algorithm.

        Args:
            f: The function to tabulate
            domain: Input domain
            num_bins: Number of bins for partitioning
            seed: Random seed for reproducibility
            max_seed_attempts: Maximum attempts for seed finding

        Returns:
            Populated function table
        """
        table = cls()

        # Stage 1: Domain partitioning
        table._partitioner = BinPartitioner(num_bins=num_bins, seed=seed)

        # Collect mappings and organize by bin
        bin_outputs: dict[int, set[Y]] = {}

        for x in domain:
            y = f(x)
            table._mappings[x] = y

            bin_idx = table._partitioner.get_bin(x)
            if bin_idx not in table._bin_mappings:
                table._bin_mappings[bin_idx] = {}
                bin_outputs[bin_idx] = set()

            table._bin_mappings[bin_idx][x] = y
            bin_outputs[bin_idx].add(y)

        # Stage 2: Seed finding
        finder = SeedFinder[Y](base_seed=seed, max_attempts=max_seed_attempts)

        for bin_idx, outputs in bin_outputs.items():
            table._bin_seeds[bin_idx] = finder.find_seeds(outputs)

        return table

    def lookup(self, x: X) -> Y | None:
        """Look up a function value.

        Args:
            x: Input value

        Returns:
            Function output or None if not in domain
        """
        return self._mappings.get(x)

    def get_bin(self, x: X) -> int | None:
        """Get the bin index for an input.

        Args:
            x: Input value

        Returns:
            Bin index or None if partitioner not initialized
        """
        if self._partitioner is None:
            return None
        return self._partitioner.get_bin(x)

    @property
    def num_bins(self) -> int:
        """Get the number of bins."""
        return self._partitioner.num_bins if self._partitioner else 0

    @property
    def total_seeds(self) -> int:
        """Get the total number of seeds across all bins."""
        return sum(len(seeds) for seeds in self._bin_seeds.values())

    @property
    def domain_size(self) -> int:
        """Get the size of the domain."""
        return len(self._mappings)


@dataclass
class Statistics:
    """Statistics about a cipher function."""

    domain_size: int = 0
    num_bins: int = 0
    total_seeds: int = 0
    average_seeds_per_bin: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
