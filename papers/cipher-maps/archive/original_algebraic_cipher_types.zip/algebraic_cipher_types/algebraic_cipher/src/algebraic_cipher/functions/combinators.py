"""Function combinators for building complex cipher functions.

Provides combinators for composing, transforming, and combining
cipher functions in a type-safe manner.
"""

from typing import TypeVar, Callable, Any, Hashable

from algebraic_cipher.functions.domain import Domain
from algebraic_cipher.functions.cipher_function import CipherFunction, FunctionConfig


X = TypeVar("X", bound=Hashable)
Y = TypeVar("Y", bound=Hashable)
Z = TypeVar("Z", bound=Hashable)
A = TypeVar("A", bound=Hashable)
B = TypeVar("B", bound=Hashable)
C = TypeVar("C", bound=Hashable)
D = TypeVar("D", bound=Hashable)


def identity(domain: Domain[X], config: FunctionConfig | None = None) -> CipherFunction[X, X]:
    """Create the identity function that preserves encryption.

    Args:
        domain: The domain for the identity function
        config: Optional function configuration

    Returns:
        Identity cipher function

    Example:
        >>> dom = Domain.from_range(0, 10)
        >>> id_fn = identity(dom)
        >>> id_fn(5)
        5
    """
    return CipherFunction.from_function(lambda x: x, domain, config)


def constant(
    value: Y,
    domain: Domain[X],
    config: FunctionConfig | None = None,
) -> CipherFunction[X, Y]:
    """Create a constant function returning encrypted constant.

    Args:
        value: The constant value to return
        domain: The input domain
        config: Optional function configuration

    Returns:
        Constant cipher function

    Example:
        >>> dom = Domain.from_range(0, 10)
        >>> always_42 = constant(42, dom)
        >>> always_42(5)
        42
    """
    return CipherFunction.from_function(lambda _: value, domain, config)


def compose(
    g: CipherFunction[Y, Z],
    f: CipherFunction[X, Y],
    config: FunctionConfig | None = None,
) -> CipherFunction[X, Z]:
    """Compose two cipher functions (g . f).

    The resulting function applies f first, then g:
        compose(g, f)(x) = g(f(x))

    Args:
        g: Second function g: Y -> Z
        f: First function f: X -> Y
        config: Optional function configuration

    Returns:
        Composed function (g . f): X -> Z

    Example:
        >>> add_one = CipherFunction.from_function(lambda x: x + 1, Domain.from_range(0, 10))
        >>> double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(1, 11))
        >>> composed = compose(double, add_one)
        >>> composed(5)  # (5 + 1) * 2 = 12
        12
    """
    def composed_fn(x: X) -> Z:
        return g(f(x))

    return CipherFunction.from_function(composed_fn, f.domain, config)


def product(
    f: CipherFunction[A, C],
    g: CipherFunction[B, D],
    config: FunctionConfig | None = None,
) -> CipherFunction[tuple[A, B], tuple[C, D]]:
    """Create product function applying f and g to pair components.

    The resulting function applies f to the first component and g to the second:
        product(f, g)((a, b)) = (f(a), g(b))

    Args:
        f: Function for first component
        g: Function for second component
        config: Optional function configuration

    Returns:
        Product function operating on pairs

    Example:
        >>> double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 5))
        >>> square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 5))
        >>> prod = product(double, square)
        >>> prod((3, 4))
        (6, 16)
    """
    # Build product domain
    product_values: list[tuple[A, B]] = []
    for a in f.domain:
        for b in g.domain:
            product_values.append((a, b))

    product_domain: Domain[tuple[A, B]] = Domain.from_values(product_values)

    def product_fn(pair: tuple[A, B]) -> tuple[C, D]:
        a, b = pair
        return (f(a), g(b))

    return CipherFunction.from_function(product_fn, product_domain, config)


def curry(
    f: CipherFunction[tuple[X, Y], Z],
    x: X,
    domain_y: Domain[Y],
    config: FunctionConfig | None = None,
) -> CipherFunction[Y, Z]:
    """Curry a binary function by fixing the first argument.

    Args:
        f: Binary function f: (X, Y) -> Z
        x: Fixed first argument
        domain_y: Domain for the second argument
        config: Optional function configuration

    Returns:
        Curried function g: Y -> Z where g(y) = f((x, y))

    Example:
        >>> add = CipherFunction.from_function(
        ...     lambda p: p[0] + p[1],
        ...     Domain.from_values([(i, j) for i in range(5) for j in range(5)])
        ... )
        >>> add_3 = curry(add, 3, Domain.from_range(0, 4))
        >>> add_3(2)
        5
    """
    def curried_fn(y: Y) -> Z:
        return f((x, y))

    return CipherFunction.from_function(curried_fn, domain_y, config)


def uncurry(
    f: Callable[[X], CipherFunction[Y, Z]],
    domain_x: Domain[X],
    domain_y: Domain[Y],
    config: FunctionConfig | None = None,
) -> CipherFunction[tuple[X, Y], Z]:
    """Uncurry a curried function.

    Args:
        f: Curried function that returns a cipher function
        domain_x: Domain for the first argument
        domain_y: Domain for the second argument
        config: Optional function configuration

    Returns:
        Uncurried function g: (X, Y) -> Z where g((x, y)) = f(x)(y)
    """
    # Build product domain
    product_values: list[tuple[X, Y]] = []
    for x in domain_x:
        for y in domain_y:
            product_values.append((x, y))

    product_domain: Domain[tuple[X, Y]] = Domain.from_values(product_values)

    def uncurried_fn(pair: tuple[X, Y]) -> Z:
        x, y = pair
        return f(x)(y)

    return CipherFunction.from_function(uncurried_fn, product_domain, config)


def map_optional(
    f: CipherFunction[X, Y],
    config: FunctionConfig | None = None,
) -> CipherFunction[X | None, Y | None]:
    """Lift a function to operate on optional values.

    Args:
        f: Function to lift
        config: Optional function configuration

    Returns:
        Lifted function that handles None values

    Example:
        >>> double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 5))
        >>> maybe_double = map_optional(double)
        >>> maybe_double(3)
        6
        >>> maybe_double(None)
        None
    """
    # Build optional domain
    optional_values: list[X | None] = [None]
    for x in f.domain:
        optional_values.append(x)

    optional_domain: Domain[X | None] = Domain.from_values(optional_values)

    def optional_fn(x: X | None) -> Y | None:
        if x is None:
            return None
        return f(x)

    return CipherFunction.from_function(optional_fn, optional_domain, config)


def parallel(
    *fns: CipherFunction[X, Any],
    config: FunctionConfig | None = None,
) -> CipherFunction[X, tuple[Any, ...]]:
    """Apply multiple functions in parallel to the same input.

    Args:
        *fns: Functions to apply
        config: Optional function configuration

    Returns:
        Function returning tuple of results

    Example:
        >>> double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 5))
        >>> square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 5))
        >>> both = parallel(double, square)
        >>> both(3)
        (6, 9)
    """
    if not fns:
        raise ValueError("At least one function required")

    # Use first function's domain
    domain = fns[0].domain

    def parallel_fn(x: X) -> tuple[Any, ...]:
        return tuple(f(x) for f in fns)

    return CipherFunction.from_function(parallel_fn, domain, config)


def fanout(
    f: CipherFunction[X, Y],
    g: CipherFunction[X, Z],
    config: FunctionConfig | None = None,
) -> CipherFunction[X, tuple[Y, Z]]:
    """Create a function that applies two functions to the same input.

    Also known as (&&&) in Haskell's Arrow.

    Args:
        f: First function
        g: Second function
        config: Optional function configuration

    Returns:
        Function returning pair of results

    Example:
        >>> double = CipherFunction.from_function(lambda x: x * 2, Domain.from_range(0, 5))
        >>> square = CipherFunction.from_function(lambda x: x * x, Domain.from_range(0, 5))
        >>> both = fanout(double, square)
        >>> both(3)
        (6, 9)
    """
    def fanout_fn(x: X) -> tuple[Y, Z]:
        return (f(x), g(x))

    return CipherFunction.from_function(fanout_fn, f.domain, config)


def split(
    f: CipherFunction[X, Y],
    g: CipherFunction[X, Z],
    config: FunctionConfig | None = None,
) -> CipherFunction[X, tuple[Y, Z]]:
    """Alias for fanout."""
    return fanout(f, g, config)
