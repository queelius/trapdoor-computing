"""Sum types - categorical coproducts (Either and Optional).

Sum types represent a choice between alternative types. They support
pattern matching and monadic operations while preserving the sum
structure in the encrypted domain.

Mathematical Properties:
- Injections: inl: A → A + B, inr: B → A + B
- Universal property: For any f: A → C, g: B → C, exists unique h: A + B → C
- Associativity: (A + B) + C ≅ A + (B + C)
- Unit laws: A + 0 ≅ A ≅ 0 + A
"""

from dataclasses import dataclass, field
from typing import TypeVar, Generic, Callable, Any
import hashlib
import secrets

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG
from algebraic_cipher.types.boolean import CipherBool


L = TypeVar("L")
R = TypeVar("R")
T = TypeVar("T")
U = TypeVar("U")


@dataclass(frozen=True, slots=True)
class Either(Generic[L, R]):
    """Sum type with left/right variants (disjoint union).

    Either represents a value that is one of two possible types:
    - Left(value): Contains a value of type L
    - Right(value): Contains a value of type R

    This is the Haskell-style Either type, commonly used for
    error handling where Left represents failure and Right represents success.

    Example:
        >>> result = Either.right(42)
        >>> result.is_right()
        True
        >>> result.get_right()
        42

        >>> error = Either.left("error message")
        >>> error.is_left()
        True
        >>> error.get_left()
        'error message'
    """

    _value: L | R
    _is_right: bool

    @classmethod
    def left(cls, value: L) -> "Either[L, Any]":
        """Create a Left variant."""
        return cls(_value=value, _is_right=False)

    @classmethod
    def right(cls, value: R) -> "Either[Any, R]":
        """Create a Right variant."""
        return cls(_value=value, _is_right=True)

    def is_left(self) -> bool:
        """Check if this is a Left variant."""
        return not self._is_right

    def is_right(self) -> bool:
        """Check if this is a Right variant."""
        return self._is_right

    def get_left(self) -> L:
        """Get the Left value.

        Raises:
            ValueError: If this is a Right variant
        """
        if self._is_right:
            raise ValueError("Cannot get left value from Right variant")
        return self._value  # type: ignore

    def get_right(self) -> R:
        """Get the Right value.

        Raises:
            ValueError: If this is a Left variant
        """
        if not self._is_right:
            raise ValueError("Cannot get right value from Left variant")
        return self._value  # type: ignore

    def match(self, left_fn: Callable[[L], T], right_fn: Callable[[R], T]) -> T:
        """Pattern match on the Either value.

        Args:
            left_fn: Function to apply if Left
            right_fn: Function to apply if Right

        Returns:
            Result of applying the appropriate function
        """
        if self._is_right:
            return right_fn(self._value)  # type: ignore
        else:
            return left_fn(self._value)  # type: ignore

    def map_left(self, f: Callable[[L], T]) -> "Either[T, R]":
        """Apply a function to the Left value if present."""
        if self._is_right:
            return Either.right(self._value)  # type: ignore
        else:
            return Either.left(f(self._value))  # type: ignore

    def map_right(self, f: Callable[[R], T]) -> "Either[L, T]":
        """Apply a function to the Right value if present."""
        if self._is_right:
            return Either.right(f(self._value))  # type: ignore
        else:
            return Either.left(self._value)  # type: ignore

    def bimap(self, f: Callable[[L], T], g: Callable[[R], U]) -> "Either[T, U]":
        """Apply functions to both variants."""
        if self._is_right:
            return Either.right(g(self._value))  # type: ignore
        else:
            return Either.left(f(self._value))  # type: ignore


@dataclass(slots=True)
class CipherEither(Generic[L, R]):
    """Encrypted Either type with homomorphic operations.

    Supports pattern matching and mapping operations that operate
    directly on encrypted values without revealing which variant
    is present.

    Example:
        >>> key = SecretKey("my-key")
        >>> encrypted = CipherEither.from_right(42, key)
        >>> encrypted.decrypt(key)
        Either.right(42)
    """

    _value: Either[L, R] | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def encrypt(
        cls, value: Either[L, R], key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherEither[L, R]":
        """Encrypt an Either value.

        Args:
            value: The Either to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher Either
        """
        if not isinstance(value, Either):
            raise TypeError(f"Expected Either, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(_value=value, _key_hash=key_hash, _config=cfg, _nonce=nonce)

    @classmethod
    def from_left(
        cls, value: L, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherEither[L, Any]":
        """Create an encrypted Left variant."""
        return cls.encrypt(Either.left(value), key, config)

    @classmethod
    def from_right(
        cls, value: R, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherEither[Any, R]":
        """Create an encrypted Right variant."""
        return cls.encrypt(Either.right(value), key, config)

    def decrypt(self, key: SecretKey) -> Either[L, R] | None:
        """Decrypt to retrieve the Either value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted Either if key is correct, None otherwise
        """
        if self._value is None:
            return None

        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if secrets.compare_digest(provided_hash, self._key_hash):
            return self._value
        return None

    def is_valid(self) -> bool:
        """Check if this cipher contains a valid encrypted value."""
        return self._value is not None and self._key_hash != ""

    def _make_result(self, value: Either[T, U]) -> "CipherEither[T, U]":
        """Create a new CipherEither with the same key."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherEither(
            _value=value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def map_left(self, f: Callable[[L], T]) -> "CipherEither[T, R]":
        """Apply a function to the Left value if present."""
        if self._value is None:
            return CipherEither()
        return self._make_result(self._value.map_left(f))

    def map_right(self, f: Callable[[R], T]) -> "CipherEither[L, T]":
        """Apply a function to the Right value if present."""
        if self._value is None:
            return CipherEither()
        return self._make_result(self._value.map_right(f))

    def bimap(self, f: Callable[[L], T], g: Callable[[R], U]) -> "CipherEither[T, U]":
        """Apply functions to both variants."""
        if self._value is None:
            return CipherEither()
        return self._make_result(self._value.bimap(f, g))

    def is_left(self) -> CipherBool:
        """Return encrypted boolean indicating if this is Left."""
        if self._value is None:
            return CipherBool()

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=self._value.is_left(),
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def is_right(self) -> CipherBool:
        """Return encrypted boolean indicating if this is Right."""
        if self._value is None:
            return CipherBool()

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=self._value.is_right(),
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    @property
    def false_positive_rate(self) -> float:
        """Either operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Either operations have zero false negative rate."""
        return 0.0


@dataclass(slots=True)
class CipherOptional(Generic[T]):
    """Encrypted Optional type (Maybe monad).

    CipherOptional represents an encrypted value that may or may not be present.
    It supports functor (fmap) and monad (bind) operations.

    Example:
        >>> key = SecretKey("my-key")
        >>> some_val = CipherOptional.some(42, key)
        >>> some_val.decrypt(key)
        42
        >>> none_val = CipherOptional.none(key)
        >>> none_val.decrypt(key)
        None

        # Functor operation
        >>> doubled = some_val.fmap(lambda x: x * 2)
        >>> doubled.decrypt(key)
        84

        # Monad operation
        >>> def safe_div(x):
        ...     return CipherOptional.some(10 // x, key) if x != 0 else CipherOptional.none(key)
        >>> result = some_val.bind(safe_div)
    """

    _value: T | None = field(default=None, repr=False)
    _has_value: bool = field(default=False, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def some(
        cls, value: T, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherOptional[T]":
        """Create an encrypted Some value (present).

        Args:
            value: The value to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted optional containing the value
        """
        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(
            _value=value,
            _has_value=True,
            _key_hash=key_hash,
            _config=cfg,
            _nonce=nonce,
        )

    @classmethod
    def none(
        cls, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherOptional[Any]":
        """Create an encrypted None value (absent).

        Args:
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted optional containing nothing
        """
        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(
            _value=None,
            _has_value=False,
            _key_hash=key_hash,
            _config=cfg,
            _nonce=nonce,
        )

    @classmethod
    def from_optional(
        cls, value: T | None, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherOptional[T]":
        """Create from a Python optional value.

        Args:
            value: The optional value (T or None)
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted optional
        """
        if value is None:
            return cls.none(key, config)
        else:
            return cls.some(value, key, config)

    def decrypt(self, key: SecretKey) -> T | None:
        """Decrypt to retrieve the optional value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted value if present and key is correct,
            None if absent or key is wrong
        """
        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if not secrets.compare_digest(provided_hash, self._key_hash):
            return None

        if self._has_value:
            return self._value
        return None

    def decrypt_with_status(self, key: SecretKey) -> tuple[bool, T | None]:
        """Decrypt and return both presence status and value.

        This allows distinguishing between "None present" and "wrong key".

        Args:
            key: Secret key for decryption

        Returns:
            Tuple of (key_valid, value) where:
            - (True, value): Key valid, value was present
            - (True, None): Key valid, value was absent
            - (False, None): Key invalid
        """
        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if not secrets.compare_digest(provided_hash, self._key_hash):
            return (False, None)

        if self._has_value:
            return (True, self._value)
        return (True, None)

    def is_valid(self) -> bool:
        """Check if this cipher was properly constructed."""
        return self._key_hash != ""

    def _make_result(self, value: U | None, has_value: bool) -> "CipherOptional[U]":
        """Create a new CipherOptional with the same key."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherOptional(
            _value=value,
            _has_value=has_value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    # Functor operation

    def fmap(self, f: Callable[[T], U]) -> "CipherOptional[U]":
        """Apply a function to the value if present (Functor fmap).

        Args:
            f: Function to apply

        Returns:
            New CipherOptional with transformed value
        """
        if not self._has_value:
            return self._make_result(None, False)

        return self._make_result(f(self._value), True)  # type: ignore

    # Monad operations

    @classmethod
    def pure(cls, value: T, key: SecretKey, config: EncodingConfig | None = None) -> "CipherOptional[T]":
        """Lift a pure value into the monadic context."""
        return cls.some(value, key, config)

    def bind(self, f: Callable[[T], "CipherOptional[U]"]) -> "CipherOptional[U]":
        """Sequence monadic computations (flatMap).

        Args:
            f: Function returning a CipherOptional

        Returns:
            Result of applying f and flattening
        """
        if not self._has_value:
            return self._make_result(None, False)

        # Apply f and return its result
        result = f(self._value)  # type: ignore
        # Copy over our key if the result used a different one
        if result._key_hash != self._key_hash:
            # Re-encrypt with our key
            if result._has_value:
                return self._make_result(result._value, True)
            else:
                return self._make_result(None, False)
        return result

    # Query operations

    def is_some(self) -> CipherBool:
        """Return encrypted boolean indicating if value is present."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=self._has_value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def is_none(self) -> CipherBool:
        """Return encrypted boolean indicating if value is absent."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=not self._has_value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def get_or_else(self, default: T, key: SecretKey) -> T:
        """Get the value or return a default.

        Args:
            default: Value to return if absent
            key: Secret key for decryption

        Returns:
            The value if present and key correct, default otherwise
        """
        result = self.decrypt(key)
        return result if result is not None else default

    @property
    def false_positive_rate(self) -> float:
        """Optional operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Optional operations have zero false negative rate."""
        return 0.0
