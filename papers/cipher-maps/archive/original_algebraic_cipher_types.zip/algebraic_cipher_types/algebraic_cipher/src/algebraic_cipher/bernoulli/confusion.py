"""Confusion matrix for Bernoulli types.

The confusion matrix is the fundamental abstraction for modeling error characteristics
in Bernoulli types. It captures the relationship between latent (true) values and
observed (approximate) values.

For boolean types, the confusion matrix is a 2x2 matrix:
    [[1-α, α  ],
     [β,   1-β]]

Where:
- α (alpha) = P(observed=1 | latent=0) = false positive rate
- β (beta)  = P(observed=0 | latent=1) = false negative rate

This generalizes the Binary Symmetric Channel (BSC) and Binary Asymmetric Channel (BAC)
from information theory to a computational type system.
"""

from dataclasses import dataclass
from typing import Self
import math


@dataclass(frozen=True, slots=True)
class ConfusionMatrix:
    """Confusion matrix defining Bernoulli type error characteristics.

    The confusion matrix captures the probabilistic relationship between
    latent (true) and observed (approximate) boolean values.

    Attributes:
        alpha: False positive rate P(obs=1|lat=0), in [0, 1]
        beta: False negative rate P(obs=0|lat=1), in [0, 1]

    Properties:
        - First-order (symmetric): α = β
        - Second-order (asymmetric): α ≠ β
        - Perfect (no error): α = β = 0

    Example:
        >>> # Binary Symmetric Channel with 10% error
        >>> bsc = ConfusionMatrix.symmetric(0.1)
        >>> bsc.alpha, bsc.beta
        (0.1, 0.1)

        >>> # Z-channel (only false negatives)
        >>> z = ConfusionMatrix(alpha=0.0, beta=0.1)
        >>> z.is_first_order()
        False
    """

    alpha: float  # False positive rate
    beta: float   # False negative rate

    def __post_init__(self) -> None:
        """Validate error rates are in [0, 1]."""
        if not (0.0 <= self.alpha <= 1.0):
            raise ValueError(f"alpha must be in [0, 1], got {self.alpha}")
        if not (0.0 <= self.beta <= 1.0):
            raise ValueError(f"beta must be in [0, 1], got {self.beta}")

    @classmethod
    def symmetric(cls, p: float) -> Self:
        """Create a first-order (symmetric) confusion matrix.

        This corresponds to the Binary Symmetric Channel (BSC) where
        the error rate is the same in both directions.

        Args:
            p: Symmetric error rate (α = β = p)

        Returns:
            Confusion matrix with symmetric error rates
        """
        return cls(alpha=p, beta=p)

    @classmethod
    def perfect(cls) -> Self:
        """Create a perfect confusion matrix (no errors).

        Returns:
            Confusion matrix with α = β = 0
        """
        return cls(alpha=0.0, beta=0.0)

    @classmethod
    def z_channel(cls, beta: float) -> Self:
        """Create a Z-channel confusion matrix.

        The Z-channel has only false negatives (ones can flip to zeros,
        but zeros never flip to ones).

        Args:
            beta: False negative rate

        Returns:
            Z-channel confusion matrix
        """
        return cls(alpha=0.0, beta=beta)

    def is_first_order(self) -> bool:
        """Check if this is a first-order (symmetric) Bernoulli type.

        First-order types have α = β, meaning the error rate is the same
        regardless of the latent value.

        Returns:
            True if symmetric (α = β), False otherwise
        """
        return math.isclose(self.alpha, self.beta)

    def is_second_order(self) -> bool:
        """Check if this is a second-order (asymmetric) Bernoulli type.

        Second-order types have α ≠ β, meaning the error rate depends
        on the latent value.

        Returns:
            True if asymmetric (α ≠ β), False otherwise
        """
        return not self.is_first_order()

    def is_perfect(self) -> bool:
        """Check if this represents perfect observation (no errors).

        Returns:
            True if α = β = 0
        """
        return math.isclose(self.alpha, 0.0) and math.isclose(self.beta, 0.0)

    def error_rate(self) -> float:
        """Get the combined error rate (average of α and β).

        This is the expected error rate assuming uniform prior on latent values.

        Returns:
            (α + β) / 2
        """
        return (self.alpha + self.beta) / 2.0

    def as_matrix(self) -> tuple[tuple[float, float], tuple[float, float]]:
        """Get the confusion matrix as a 2x2 tuple.

        Returns:
            ((1-α, α), (β, 1-β))
        """
        return (
            (1.0 - self.alpha, self.alpha),
            (self.beta, 1.0 - self.beta),
        )

    def channel_capacity(self) -> float:
        """Compute the channel capacity for this confusion matrix.

        For a binary channel, capacity is:
            C = 1 - H(α) for BSC
            C = log(1 + (1-β)^{(1-β)/β} * α^{α/(1-α)}) for BAC

        For simplicity, returns the BSC approximation using average error.

        Returns:
            Approximate channel capacity in bits
        """
        avg_error = self.error_rate()
        if avg_error == 0.0 or avg_error == 1.0:
            return 1.0 if avg_error == 0.0 else 0.0

        # Binary entropy function H(p)
        h_p = -avg_error * math.log2(avg_error) - (1 - avg_error) * math.log2(1 - avg_error)
        return 1.0 - h_p

    def __repr__(self) -> str:
        if self.is_first_order():
            return f"ConfusionMatrix.symmetric({self.alpha})"
        return f"ConfusionMatrix(alpha={self.alpha}, beta={self.beta})"


@dataclass(frozen=True, slots=True)
class ErrorRateSpan:
    """Interval representation of error rates for uncertainty tracking.

    When error rates cannot be determined exactly (e.g., after composition),
    we track bounds instead of point estimates.

    Attributes:
        min_rate: Lower bound on error rate
        max_rate: Upper bound on error rate

    Example:
        >>> span = ErrorRateSpan(0.01, 0.05)
        >>> span.contains(0.03)
        True
    """

    min_rate: float
    max_rate: float

    def __post_init__(self) -> None:
        """Validate span bounds."""
        if not (0.0 <= self.min_rate <= 1.0):
            raise ValueError(f"min_rate must be in [0, 1], got {self.min_rate}")
        if not (0.0 <= self.max_rate <= 1.0):
            raise ValueError(f"max_rate must be in [0, 1], got {self.max_rate}")
        if self.min_rate > self.max_rate:
            raise ValueError(f"min_rate ({self.min_rate}) > max_rate ({self.max_rate})")

    @classmethod
    def point(cls, rate: float) -> Self:
        """Create a point estimate (exact error rate).

        Args:
            rate: Exact error rate

        Returns:
            Span with min = max = rate
        """
        return cls(min_rate=rate, max_rate=rate)

    @classmethod
    def from_confusion_matrix(cls, cm: ConfusionMatrix) -> tuple[Self, Self]:
        """Create spans for α and β from a confusion matrix.

        Args:
            cm: Confusion matrix

        Returns:
            (alpha_span, beta_span)
        """
        return (cls.point(cm.alpha), cls.point(cm.beta))

    def is_point(self) -> bool:
        """Check if this is a point estimate (no uncertainty).

        Returns:
            True if min_rate == max_rate
        """
        return math.isclose(self.min_rate, self.max_rate)

    def midpoint(self) -> float:
        """Get the midpoint of the span.

        Returns:
            (min_rate + max_rate) / 2
        """
        return (self.min_rate + self.max_rate) / 2.0

    def width(self) -> float:
        """Get the width of the span.

        Returns:
            max_rate - min_rate
        """
        return self.max_rate - self.min_rate

    def contains(self, rate: float) -> bool:
        """Check if a rate falls within this span.

        Args:
            rate: Error rate to check

        Returns:
            True if min_rate <= rate <= max_rate
        """
        return self.min_rate <= rate <= self.max_rate

    def union(self, other: Self) -> Self:
        """Compute the union of two spans.

        Args:
            other: Another span

        Returns:
            Span containing both input spans
        """
        return ErrorRateSpan(
            min_rate=min(self.min_rate, other.min_rate),
            max_rate=max(self.max_rate, other.max_rate),
        )

    def intersection(self, other: Self) -> Self | None:
        """Compute the intersection of two spans.

        Args:
            other: Another span

        Returns:
            Overlapping span, or None if disjoint
        """
        new_min = max(self.min_rate, other.min_rate)
        new_max = min(self.max_rate, other.max_rate)
        if new_min > new_max:
            return None
        return ErrorRateSpan(new_min, new_max)

    def __repr__(self) -> str:
        if self.is_point():
            return f"ErrorRateSpan.point({self.min_rate})"
        return f"ErrorRateSpan({self.min_rate}, {self.max_rate})"
