"""Protocol definitions for cipher type abstractions.

This module defines the type-theoretic protocols that cipher types must satisfy:
- CipherType: Basic encryption/decryption interface
- Functor: fmap capability (structure-preserving map)
- Monad: bind/flatmap capability (sequencing computations)
"""

from typing import Protocol, TypeVar, Callable, runtime_checkable

from algebraic_cipher.core.key import SecretKey

T = TypeVar("T")
U = TypeVar("U")


@runtime_checkable
class CipherType(Protocol[T]):
    """Protocol for types that support encryption and decryption.

    The fundamental law all cipher types must satisfy (homomorphic property):
        decrypt(op(encrypt(a), encrypt(b))) == op(a, b)

    Where op is any algebraic operation supported by the type.
    """

    @classmethod
    def encrypt(cls, value: T, key: SecretKey) -> "CipherType[T]":
        """Encrypt a plaintext value.

        Args:
            value: The plaintext value to encrypt
            key: Secret key for encryption

        Returns:
            Encrypted cipher value
        """
        ...

    def decrypt(self, key: SecretKey) -> T | None:
        """Decrypt to retrieve the plaintext value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted value if key is correct, None otherwise
        """
        ...


@runtime_checkable
class Functor(Protocol[T]):
    """Protocol for types supporting functorial mapping.

    Functor Laws:
    1. Identity: fmap(id) == id
    2. Composition: fmap(g . f) == fmap(g) . fmap(f)

    These laws ensure structure-preserving transformations.
    """

    def fmap(self, f: Callable[[T], U]) -> "Functor[U]":
        """Apply a function to the wrapped value while preserving structure.

        Args:
            f: Function to apply to the inner value

        Returns:
            New functor wrapping the transformed value
        """
        ...


@runtime_checkable
class Monad(Functor[T], Protocol[T]):
    """Protocol for types supporting monadic operations.

    Monad Laws:
    1. Left identity: return(a).bind(f) == f(a)
    2. Right identity: m.bind(return) == m
    3. Associativity: m.bind(f).bind(g) == m.bind(lambda x: f(x).bind(g))

    These laws ensure proper sequencing of effectful computations.
    """

    @classmethod
    def pure(cls, value: T) -> "Monad[T]":
        """Lift a pure value into the monadic context.

        Also known as 'return' in Haskell.

        Args:
            value: Pure value to lift

        Returns:
            Monadic wrapper around the value
        """
        ...

    def bind(self, f: Callable[[T], "Monad[U]"]) -> "Monad[U]":
        """Sequence monadic computations.

        Also known as 'flatMap' or '>>=' (bind operator).

        Args:
            f: Function returning a monad

        Returns:
            Result of applying f to the inner value and flattening
        """
        ...


class Applicative(Functor[T], Protocol[T]):
    """Protocol for applicative functors.

    Applicative Laws:
    1. Identity: pure(id) <*> v == v
    2. Composition: pure(.) <*> u <*> v <*> w == u <*> (v <*> w)
    3. Homomorphism: pure(f) <*> pure(x) == pure(f(x))
    4. Interchange: u <*> pure(y) == pure(lambda f: f(y)) <*> u
    """

    @classmethod
    def pure(cls, value: T) -> "Applicative[T]":
        """Lift a pure value into the applicative context."""
        ...

    def apply(self, f: "Applicative[Callable[[T], U]]") -> "Applicative[U]":
        """Apply a wrapped function to a wrapped value.

        Args:
            f: Wrapped function to apply

        Returns:
            Result of applying the function
        """
        ...
