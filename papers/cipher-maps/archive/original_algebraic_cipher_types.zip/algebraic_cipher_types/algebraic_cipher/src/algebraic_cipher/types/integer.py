"""Integer cipher with homomorphic ring operations.

This module provides encryption for integer types with support for homomorphic
arithmetic operations. It preserves the ring structure of integers under
addition and multiplication.

Ring Properties (Preserved):
- Additive identity: a + 0 = a
- Additive inverse: a + (-a) = 0
- Additive commutativity: a + b = b + a
- Additive associativity: (a + b) + c = a + (b + c)
- Multiplicative identity: a * 1 = a
- Multiplicative commutativity: a * b = b * a
- Multiplicative associativity: (a * b) * c = a * (b * c)
- Distributivity: a * (b + c) = (a * b) + (a * c)
"""

from dataclasses import dataclass, field
import hashlib
import secrets

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG
from algebraic_cipher.types.boolean import CipherBool


@dataclass(slots=True)
class CipherInteger:
    """Encrypted integer with homomorphic ring operations.

    Supports arithmetic operations (+, -, *, unary -) and comparison
    operations (==, !=, <, <=, >, >=) that return encrypted booleans.

    Example:
        >>> key = SecretKey("my-key")
        >>> a = CipherInteger.encrypt(42, key)
        >>> b = CipherInteger.encrypt(17, key)
        >>> (a + b).decrypt(key)
        59
        >>> (a - b).decrypt(key)
        25
        >>> (a * b).decrypt(key)
        714
        >>> (-a).decrypt(key)
        -42
        >>> (a > b).decrypt(key)
        True
    """

    _value: int | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def encrypt(
        cls, value: int, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherInteger":
        """Encrypt an integer value.

        Args:
            value: The integer to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher integer
        """
        if not isinstance(value, int) or isinstance(value, bool):
            raise TypeError(f"Expected int, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(_value=value, _key_hash=key_hash, _config=cfg, _nonce=nonce)

    def decrypt(self, key: SecretKey) -> int | None:
        """Decrypt to retrieve the integer value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted integer if key is correct, None otherwise
        """
        if self._value is None:
            return None

        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if secrets.compare_digest(provided_hash, self._key_hash):
            return self._value
        return None

    def is_valid(self) -> bool:
        """Check if this cipher contains a valid encrypted value."""
        return self._value is not None and self._key_hash != ""

    def _make_result(self, value: int) -> "CipherInteger":
        """Create a new CipherInteger with the same key but a new value."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherInteger(
            _value=value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def _make_bool_result(self, value: bool) -> CipherBool:
        """Create a CipherBool result with the same key."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def _check_compatible(self, other: "CipherInteger") -> None:
        """Verify that two ciphers are compatible for operations."""
        if self._key_hash != other._key_hash:
            raise ValueError("Cannot perform operation on ciphers with different keys")

    # Homomorphic arithmetic operations

    def __add__(self, other: "CipherInteger") -> "CipherInteger":
        """Homomorphic addition.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted sum (self + other)
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherInteger()

        return self._make_result(self._value + other._value)

    def __sub__(self, other: "CipherInteger") -> "CipherInteger":
        """Homomorphic subtraction.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted difference (self - other)
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherInteger()

        return self._make_result(self._value - other._value)

    def __mul__(self, other: "CipherInteger") -> "CipherInteger":
        """Homomorphic multiplication.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted product (self * other)
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherInteger()

        return self._make_result(self._value * other._value)

    def __neg__(self) -> "CipherInteger":
        """Homomorphic unary negation.

        Returns:
            Encrypted negation (-self)
        """
        if self._value is None:
            return CipherInteger()

        return self._make_result(-self._value)

    def __pos__(self) -> "CipherInteger":
        """Unary positive (no-op).

        Returns:
            Copy of self
        """
        if self._value is None:
            return CipherInteger()

        return self._make_result(self._value)

    def __abs__(self) -> "CipherInteger":
        """Homomorphic absolute value.

        Returns:
            Encrypted absolute value
        """
        if self._value is None:
            return CipherInteger()

        return self._make_result(abs(self._value))

    # Integer-specific operations

    def __floordiv__(self, other: "CipherInteger") -> "CipherInteger":
        """Homomorphic integer division.

        Args:
            other: Divisor (encrypted integer)

        Returns:
            Encrypted quotient (self // other)
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherInteger()

        if other._value == 0:
            raise ZeroDivisionError("integer division by zero")

        return self._make_result(self._value // other._value)

    def __mod__(self, other: "CipherInteger") -> "CipherInteger":
        """Homomorphic modulo operation.

        Args:
            other: Divisor (encrypted integer)

        Returns:
            Encrypted remainder (self % other)
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherInteger()

        if other._value == 0:
            raise ZeroDivisionError("integer modulo by zero")

        return self._make_result(self._value % other._value)

    # Comparison operations (return encrypted booleans)

    def __eq__(self, other: object) -> bool:
        """Structural equality check.

        For encrypted equality comparison, use cipher_eq().
        """
        if not isinstance(other, CipherInteger):
            return NotImplemented
        return self._value == other._value and self._key_hash == other._key_hash

    def cipher_eq(self, other: "CipherInteger") -> CipherBool:
        """Encrypted equality comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self == other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value == other._value)

    def cipher_ne(self, other: "CipherInteger") -> CipherBool:
        """Encrypted inequality comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self != other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value != other._value)

    def cipher_lt(self, other: "CipherInteger") -> CipherBool:
        """Encrypted less-than comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self < other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value < other._value)

    def cipher_le(self, other: "CipherInteger") -> CipherBool:
        """Encrypted less-than-or-equal comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self <= other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value <= other._value)

    def cipher_gt(self, other: "CipherInteger") -> CipherBool:
        """Encrypted greater-than comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self > other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value > other._value)

    def cipher_ge(self, other: "CipherInteger") -> CipherBool:
        """Encrypted greater-than-or-equal comparison.

        Args:
            other: Another encrypted integer

        Returns:
            Encrypted boolean (self >= other)
        """
        if not isinstance(other, CipherInteger):
            raise TypeError(f"Expected CipherInteger, got {type(other)}")

        self._check_compatible(other)

        if self._value is None or other._value is None:
            return CipherBool()

        return self._make_bool_result(self._value >= other._value)

    @property
    def false_positive_rate(self) -> float:
        """Integer operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Integer operations have zero false negative rate."""
        return 0.0

    # Factory methods for common values

    @classmethod
    def zero(cls, key: SecretKey, config: EncodingConfig | None = None) -> "CipherInteger":
        """Create an encrypted zero value (additive identity)."""
        return cls.encrypt(0, key, config)

    @classmethod
    def one(cls, key: SecretKey, config: EncodingConfig | None = None) -> "CipherInteger":
        """Create an encrypted one value (multiplicative identity)."""
        return cls.encrypt(1, key, config)
