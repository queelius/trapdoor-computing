"""Product types - categorical products (pairs and tuples).

Product types represent the combination of multiple values into a single
compound value. They support projections and bimap operations while
preserving the product structure in the encrypted domain.

Mathematical Properties:
- Projections: fst: A × B → A, snd: A × B → B
- Universal property: For any f: C → A, g: C → B, exists unique h: C → A × B
- Associativity: (A × B) × C ≅ A × (B × C)
- Unit laws: A × 1 ≅ A ≅ 1 × A
"""

from dataclasses import dataclass, field
from typing import TypeVar, Generic, Callable, Any, overload
import hashlib
import secrets

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG


A = TypeVar("A")
B = TypeVar("B")
C = TypeVar("C")
D = TypeVar("D")


@dataclass(slots=True)
class CipherPair(Generic[A, B]):
    """Encrypted pair (product of two types).

    Supports projections (first, second), swapping, and bimap operations
    that operate directly on encrypted values.

    Example:
        >>> key = SecretKey("my-key")
        >>> pair = CipherPair.encrypt((42, "hello"), key)
        >>> pair.first(key)
        42
        >>> pair.second(key)
        'hello'
        >>> swapped = pair.swap()
        >>> swapped.first(key)
        'hello'
    """

    _first: A | None = field(default=None, repr=False)
    _second: B | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def encrypt(
        cls, value: tuple[A, B], key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherPair[A, B]":
        """Encrypt a pair value.

        Args:
            value: A tuple (a, b) to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher pair
        """
        if not isinstance(value, tuple) or len(value) != 2:
            raise TypeError(f"Expected tuple of length 2, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(
            _first=value[0],
            _second=value[1],
            _key_hash=key_hash,
            _config=cfg,
            _nonce=nonce,
        )

    def decrypt(self, key: SecretKey) -> tuple[A, B] | None:
        """Decrypt to retrieve the pair value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted tuple if key is correct, None otherwise
        """
        if self._first is None or self._second is None:
            return None

        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if secrets.compare_digest(provided_hash, self._key_hash):
            return (self._first, self._second)
        return None

    def is_valid(self) -> bool:
        """Check if this cipher contains valid encrypted values."""
        return self._first is not None and self._second is not None and self._key_hash != ""

    # Projections

    def first(self, key: SecretKey) -> A | None:
        """Get the first component of the pair.

        Args:
            key: Secret key for decryption

        Returns:
            The first component if key is correct, None otherwise
        """
        result = self.decrypt(key)
        return result[0] if result else None

    def second(self, key: SecretKey) -> B | None:
        """Get the second component of the pair.

        Args:
            key: Secret key for decryption

        Returns:
            The second component if key is correct, None otherwise
        """
        result = self.decrypt(key)
        return result[1] if result else None

    # Structural operations

    def swap(self) -> "CipherPair[B, A]":
        """Swap the components of the pair.

        Returns:
            New cipher pair with swapped components
        """
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherPair(
            _first=self._second,
            _second=self._first,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def bimap(self, f: Callable[[A], C], g: Callable[[B], D]) -> "CipherPair[C, D]":
        """Apply functions to both components of the pair.

        Args:
            f: Function to apply to the first component
            g: Function to apply to the second component

        Returns:
            New cipher pair with transformed components
        """
        if self._first is None or self._second is None:
            return CipherPair()

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherPair(
            _first=f(self._first),
            _second=g(self._second),
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def map_first(self, f: Callable[[A], C]) -> "CipherPair[C, B]":
        """Apply a function to the first component.

        Args:
            f: Function to apply

        Returns:
            New cipher pair with transformed first component
        """
        return self.bimap(f, lambda x: x)

    def map_second(self, g: Callable[[B], D]) -> "CipherPair[A, D]":
        """Apply a function to the second component.

        Args:
            g: Function to apply

        Returns:
            New cipher pair with transformed second component
        """
        return self.bimap(lambda x: x, g)

    @property
    def false_positive_rate(self) -> float:
        """Pair operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Pair operations have zero false negative rate."""
        return 0.0


@dataclass(slots=True)
class CipherTuple(Generic[A]):
    """Encrypted tuple (generalized product type).

    Supports element access, mapping, and structural operations on
    encrypted tuples of arbitrary length.

    Example:
        >>> key = SecretKey("my-key")
        >>> ct = CipherTuple.encrypt((1, "hello", True), key)
        >>> ct.get(0, key)
        1
        >>> ct.get(1, key)
        'hello'
        >>> ct.length()
        3
    """

    _values: tuple[Any, ...] | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def encrypt(
        cls, value: tuple[Any, ...], key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherTuple[Any]":
        """Encrypt a tuple value.

        Args:
            value: A tuple to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher tuple
        """
        if not isinstance(value, tuple):
            raise TypeError(f"Expected tuple, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(
            _values=value,
            _key_hash=key_hash,
            _config=cfg,
            _nonce=nonce,
        )

    def decrypt(self, key: SecretKey) -> tuple[Any, ...] | None:
        """Decrypt to retrieve the tuple value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted tuple if key is correct, None otherwise
        """
        if self._values is None:
            return None

        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if secrets.compare_digest(provided_hash, self._key_hash):
            return self._values
        return None

    def is_valid(self) -> bool:
        """Check if this cipher contains a valid encrypted tuple."""
        return self._values is not None and self._key_hash != ""

    def length(self) -> int:
        """Get the length of the encrypted tuple."""
        return len(self._values) if self._values else 0

    def get(self, index: int, key: SecretKey) -> Any | None:
        """Get an element from the tuple by index.

        Args:
            index: The index of the element to retrieve
            key: Secret key for decryption

        Returns:
            The element at the given index if key is correct, None otherwise
        """
        result = self.decrypt(key)
        if result is None:
            return None
        if 0 <= index < len(result):
            return result[index]
        raise IndexError(f"tuple index {index} out of range")

    def map(self, f: Callable[[Any], Any]) -> "CipherTuple[Any]":
        """Apply a function to all elements of the tuple.

        Args:
            f: Function to apply to each element

        Returns:
            New cipher tuple with transformed elements
        """
        if self._values is None:
            return CipherTuple()

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherTuple(
            _values=tuple(f(v) for v in self._values),
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def map_at(self, index: int, f: Callable[[Any], Any]) -> "CipherTuple[Any]":
        """Apply a function to the element at a specific index.

        Args:
            index: The index of the element to transform
            f: Function to apply

        Returns:
            New cipher tuple with the element at index transformed
        """
        if self._values is None:
            return CipherTuple()

        if not (0 <= index < len(self._values)):
            raise IndexError(f"tuple index {index} out of range")

        new_values = list(self._values)
        new_values[index] = f(new_values[index])

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherTuple(
            _values=tuple(new_values),
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    def to_pair(self) -> CipherPair[Any, Any]:
        """Convert a 2-tuple to a CipherPair.

        Returns:
            CipherPair containing the same elements

        Raises:
            ValueError: If the tuple doesn't have exactly 2 elements
        """
        if self._values is None or len(self._values) != 2:
            raise ValueError("Can only convert 2-tuples to pairs")

        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherPair(
            _first=self._values[0],
            _second=self._values[1],
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    @property
    def false_positive_rate(self) -> float:
        """Tuple operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Tuple operations have zero false negative rate."""
        return 0.0


# Convenience function for creating pairs
def make_cipher_pair(
    a: A, b: B, key: SecretKey, config: EncodingConfig | None = None
) -> CipherPair[A, B]:
    """Create an encrypted pair from two values.

    Args:
        a: First component
        b: Second component
        key: Secret key for encryption
        config: Optional encoding configuration

    Returns:
        Encrypted cipher pair
    """
    return CipherPair.encrypt((a, b), key, config)


# Convenience function for creating tuples
def make_cipher_tuple(
    *values: Any, key: SecretKey, config: EncodingConfig | None = None
) -> CipherTuple[Any]:
    """Create an encrypted tuple from values.

    Args:
        *values: Values to include in the tuple
        key: Secret key for encryption
        config: Optional encoding configuration

    Returns:
        Encrypted cipher tuple
    """
    return CipherTuple.encrypt(values, key, config)
