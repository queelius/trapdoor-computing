"""Base cipher class providing encryption infrastructure.

This module defines the abstract base for all cipher types, establishing
the common interface and implementation patterns.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TypeVar, Generic, Callable
import hashlib
import secrets

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG

T = TypeVar("T")
U = TypeVar("U")


def _compute_hash(value: bytes, key: SecretKey, config: EncodingConfig) -> str:
    """Compute a keyed hash of a value.

    Uses HMAC-like construction for security.
    """
    key_bytes = key.value.encode("utf-8")
    combined = key_bytes + value + str(config.security_parameter).encode()

    if config.use_randomization:
        nonce = secrets.token_bytes(16)
        combined = nonce + combined

    return hashlib.sha256(combined).hexdigest()


def _verify_key(stored_key_hash: str, provided_key: SecretKey) -> bool:
    """Verify that the provided key matches the stored key hash."""
    provided_hash = hashlib.sha256(provided_key.value.encode()).hexdigest()
    return secrets.compare_digest(stored_key_hash, provided_hash)


@dataclass
class CipherBase(ABC, Generic[T]):
    """Abstract base class for cipher types.

    This provides the common infrastructure for all cipher implementations:
    - Key verification on decryption
    - Configuration management
    - Error rate tracking

    Subclasses must implement:
    - _encrypt_value: Actual encryption logic
    - _decrypt_value: Actual decryption logic
    - Homomorphic operations specific to their type
    """

    _value: T | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    @abstractmethod
    def encrypt(cls, value: T, key: SecretKey, config: EncodingConfig | None = None) -> "CipherBase[T]":
        """Encrypt a plaintext value.

        Args:
            value: The plaintext value to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher value
        """
        ...

    @abstractmethod
    def decrypt(self, key: SecretKey) -> T | None:
        """Decrypt to retrieve the plaintext value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted value if key is correct, None otherwise
        """
        ...

    def _verify_key(self, key: SecretKey) -> bool:
        """Check if the provided key matches the encryption key."""
        return _verify_key(self._key_hash, key)

    def _store_key_hash(self, key: SecretKey) -> str:
        """Store a hash of the key for later verification."""
        return hashlib.sha256(key.value.encode()).hexdigest()

    @property
    def config(self) -> EncodingConfig:
        """Get the encoding configuration."""
        return self._config

    @property
    def false_positive_rate(self) -> float:
        """Get the false positive rate for this cipher."""
        return self._config.false_positive_rate

    @property
    def false_negative_rate(self) -> float:
        """Get the false negative rate for this cipher."""
        return self._config.false_negative_rate

    def is_valid(self) -> bool:
        """Check if this cipher contains a valid encrypted value."""
        return self._value is not None and self._key_hash != ""
