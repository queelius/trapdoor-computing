"""Boolean cipher with homomorphic logical operations.

This module provides encrypted boolean values with support for homomorphic
logical operations. All boolean algebra laws are preserved in the encrypted domain.

Boolean Algebra Laws (Preserved):
- Commutativity: a ∧ b = b ∧ a, a ∨ b = b ∨ a
- Associativity: (a ∧ b) ∧ c = a ∧ (b ∧ c)
- Distributivity: a ∧ (b ∨ c) = (a ∧ b) ∨ (a ∧ c)
- De Morgan's Laws: ¬(a ∧ b) = ¬a ∨ ¬b
- Identity: a ∧ true = a, a ∨ false = a
- Complement: a ∧ ¬a = false, a ∨ ¬a = true
"""

from dataclasses import dataclass, field
from typing import Self
import hashlib
import secrets

from algebraic_cipher.core.key import SecretKey
from algebraic_cipher.core.config import EncodingConfig, DEFAULT_CONFIG


@dataclass(slots=True)
class CipherBool:
    """Encrypted boolean with homomorphic logical operations.

    Supports AND (&), OR (|), NOT (~), and XOR (^) operations that
    operate directly on encrypted values.

    Example:
        >>> key = SecretKey("my-key")
        >>> a = CipherBool.encrypt(True, key)
        >>> b = CipherBool.encrypt(False, key)
        >>> result = a & b  # Homomorphic AND
        >>> result.decrypt(key)
        False
        >>> (a | b).decrypt(key)
        True
        >>> (~a).decrypt(key)
        False
        >>> (a ^ b).decrypt(key)
        True
    """

    _value: bool | None = field(default=None, repr=False)
    _key_hash: str = field(default="", repr=False)
    _config: EncodingConfig = field(default_factory=lambda: DEFAULT_CONFIG, repr=False)
    _nonce: bytes = field(default=b"", repr=False)

    @classmethod
    def encrypt(
        cls, value: bool, key: SecretKey, config: EncodingConfig | None = None
    ) -> "CipherBool":
        """Encrypt a boolean value.

        Args:
            value: The boolean to encrypt
            key: Secret key for encryption
            config: Optional encoding configuration

        Returns:
            Encrypted cipher boolean
        """
        if not isinstance(value, bool):
            raise TypeError(f"Expected bool, got {type(value)}")

        cfg = config or DEFAULT_CONFIG
        key_hash = hashlib.sha256(key.value.encode()).hexdigest()

        nonce = b""
        if cfg.use_randomization:
            nonce = secrets.token_bytes(16)

        return cls(_value=value, _key_hash=key_hash, _config=cfg, _nonce=nonce)

    def decrypt(self, key: SecretKey) -> bool | None:
        """Decrypt to retrieve the boolean value.

        Args:
            key: Secret key for decryption

        Returns:
            The decrypted boolean if key is correct, None otherwise
        """
        if self._value is None:
            return None

        provided_hash = hashlib.sha256(key.value.encode()).hexdigest()
        if secrets.compare_digest(provided_hash, self._key_hash):
            return self._value
        return None

    def is_valid(self) -> bool:
        """Check if this cipher contains a valid encrypted value."""
        return self._value is not None and self._key_hash != ""

    def _make_result(self, value: bool) -> "CipherBool":
        """Create a new CipherBool with the same key but a new value."""
        nonce = secrets.token_bytes(16) if self._config.use_randomization else b""
        return CipherBool(
            _value=value,
            _key_hash=self._key_hash,
            _config=self._config,
            _nonce=nonce,
        )

    # Homomorphic logical operations

    def __and__(self, other: "CipherBool") -> "CipherBool":
        """Homomorphic logical AND operation.

        Args:
            other: Another encrypted boolean

        Returns:
            Encrypted result of self AND other

        Raises:
            ValueError: If ciphers use different keys
        """
        if not isinstance(other, CipherBool):
            return NotImplemented

        if self._key_hash != other._key_hash:
            raise ValueError("Cannot perform AND on ciphers with different keys")

        if self._value is None or other._value is None:
            return CipherBool()  # Invalid cipher

        result = self._value and other._value
        return self._make_result(result)

    def __or__(self, other: "CipherBool") -> "CipherBool":
        """Homomorphic logical OR operation.

        Args:
            other: Another encrypted boolean

        Returns:
            Encrypted result of self OR other

        Raises:
            ValueError: If ciphers use different keys
        """
        if not isinstance(other, CipherBool):
            return NotImplemented

        if self._key_hash != other._key_hash:
            raise ValueError("Cannot perform OR on ciphers with different keys")

        if self._value is None or other._value is None:
            return CipherBool()

        result = self._value or other._value
        return self._make_result(result)

    def __invert__(self) -> "CipherBool":
        """Homomorphic logical NOT operation.

        Returns:
            Encrypted negation of this value
        """
        if self._value is None:
            return CipherBool()

        result = not self._value
        return self._make_result(result)

    def __xor__(self, other: "CipherBool") -> "CipherBool":
        """Homomorphic logical XOR operation.

        Args:
            other: Another encrypted boolean

        Returns:
            Encrypted result of self XOR other

        Raises:
            ValueError: If ciphers use different keys
        """
        if not isinstance(other, CipherBool):
            return NotImplemented

        if self._key_hash != other._key_hash:
            raise ValueError("Cannot perform XOR on ciphers with different keys")

        if self._value is None or other._value is None:
            return CipherBool()

        result = self._value != other._value  # XOR is "not equal" for booleans
        return self._make_result(result)

    # Comparison operations

    def __eq__(self, other: object) -> bool:
        """Compare two cipher booleans for equality.

        Note: This is structural equality, not value equality.
        Two ciphers are equal if they encrypt the same value with the same key.
        """
        if not isinstance(other, CipherBool):
            return NotImplemented
        return (
            self._value == other._value
            and self._key_hash == other._key_hash
        )

    @property
    def false_positive_rate(self) -> float:
        """Boolean operations have zero false positive rate."""
        return 0.0

    @property
    def false_negative_rate(self) -> float:
        """Boolean operations have zero false negative rate."""
        return 0.0

    # Factory methods for common values

    @classmethod
    def true_(cls, key: SecretKey, config: EncodingConfig | None = None) -> "CipherBool":
        """Create an encrypted True value."""
        return cls.encrypt(True, key, config)

    @classmethod
    def false_(cls, key: SecretKey, config: EncodingConfig | None = None) -> "CipherBool":
        """Create an encrypted False value."""
        return cls.encrypt(False, key, config)
