# Algebraic Cipher Types

A Python library for algebraic cipher types with homomorphic properties, providing a type-safe framework for secure computation through homomorphic operations on encrypted algebraic structures.

## Overview

This library implements the cipher functor that lifts a monoid (S, *) to an encrypted monoid c_A(S, *) where:

- **S** is the underlying algebraic structure (e.g., integers under addition)
- **A** is the encoding set
- The **homomorphic property** preserves: `decrypt(op(encrypt(a), encrypt(b))) = op(a, b)`

## Features

- **Type-safe encryption**: Strongly typed cipher types for booleans, integers, pairs, tuples, and optional values
- **Homomorphic operations**: Operations on encrypted values without decryption
- **Algebraic laws preserved**: Ring laws for integers, Boolean algebra laws for booleans
- **Functor and Monad support**: `fmap` and `bind` operations for composition
- **Cipher functions**: Two-stage algorithm for homomorphic function evaluation

## Installation

```bash
pip install algebraic_cipher
```

For development:

```bash
pip install -e ".[dev]"
```

## Quick Start

```python
from algebraic_cipher import SecretKey, CipherBool, CipherInteger

# Create a secret key
key = SecretKey("my-secure-key")

# Boolean operations
a = CipherBool.encrypt(True, key)
b = CipherBool.encrypt(False, key)
result = a & b  # Homomorphic AND
print(result.decrypt(key))  # False

# Integer operations
x = CipherInteger.encrypt(42, key)
y = CipherInteger.encrypt(17, key)
sum_result = x + y  # Homomorphic addition
print(sum_result.decrypt(key))  # 59
```

## Supported Types

| Type | Operations |
|------|------------|
| `CipherBool` | AND, OR, NOT, XOR |
| `CipherInteger` | +, -, *, //, %, comparisons |
| `CipherPair[A,B]` | first, second, swap, bimap |
| `CipherTuple` | get, map, map_at |
| `CipherOptional[T]` | fmap, bind, is_some, is_none |
| `CipherEither[L,R]` | map_left, map_right, bimap |

## Cipher Functions

For evaluating arbitrary functions on encrypted values:

```python
from algebraic_cipher import CipherFunction, Domain

# Create a cipher function
square = CipherFunction.from_function(
    lambda x: x * x,
    Domain.from_range(0, 100)
)

# Apply to encrypted value
encrypted_5 = CipherInteger.encrypt(5, key)
result = square.apply(encrypted_5, key)
print(result.decrypt(key))  # 25
```

## Mathematical Properties

The library preserves fundamental algebraic laws:

**Boolean Algebra**:
- De Morgan's Laws: `~(a & b) == ~a | ~b`
- Distributivity: `a & (b | c) == (a & b) | (a & c)`

**Integer Ring**:
- Additive identity: `a + 0 == a`
- Multiplicative identity: `a * 1 == a`
- Distributivity: `a * (b + c) == a*b + a*c`

**Functor Laws** (for CipherOptional):
- Identity: `fmap(id) == id`
- Composition: `fmap(g . f) == fmap(g) . fmap(f)`

**Monad Laws** (for CipherOptional):
- Left identity: `pure(a).bind(f) == f(a)`
- Right identity: `m.bind(pure) == m`
- Associativity: `m.bind(f).bind(g) == m.bind(λx. f(x).bind(g))`

## Running Tests

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=algebraic_cipher --cov-report=term-missing

# Run property-based tests
pytest tests/test_properties/ -v
```

## Type Checking

```bash
mypy src/algebraic_cipher/
```

## License

MIT License
