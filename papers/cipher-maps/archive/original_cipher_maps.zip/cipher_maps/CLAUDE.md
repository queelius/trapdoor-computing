# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Academic research paper on **Cipher Maps**: a unified theoretical framework for oblivious function approximation through algebraic structures and Bernoulli models.

## Build Commands

```bash
# Compile PDF (runs pdflatex + bibtex, copies to root)
make

# Clean build artifacts (.aux, .log, etc.)
make clean

# Remove all generated files including PDFs
make cleanall

# Watch for changes and rebuild (requires inotifywait)
make watch
```

## Project Structure

```
cipher_maps/
├── paper/
│   ├── cipher_maps.tex       # Main LaTeX source
│   └── img/                  # TikZ figures
├── Makefile                  # Build automation
├── CITATION.cff              # GitHub citation metadata
├── zenodo.json               # Zenodo archival metadata
└── cipher_maps.pdf           # Compiled PDF (copied from paper/)
```

## Key Concepts

The paper unifies three theoretical frameworks:

1. **Cipher Functors**: Algebraic structures that lift monoids to cipher monoids, enabling multiple representations of the same element for obliviousness
2. **Bernoulli Approximations**: Probabilistic functions with controlled false positive (ε) and false negative (η) error rates
3. **Singular Hash Map**: Space-optimal data structure achieving `-log₂ε + μ` bits per element

## Mathematical Framework

- **Cipher functor** `c_A` lifts monoid `(S, *, e)` to cipher monoid with encoding/decoding functions
- **Bernoulli confusion matrix** `Q = [q_ij]` where `q_ij = Pr[observe p_j | latent p_i]`
- **Space complexity bound**: `-(1-η)log₂ε + (1-η)μ` bits per element

## LaTeX Conventions

- Theorem environments: `definition`, `theorem`, `lemma`, `corollary`, `proposition`, `remark`, `example`
- Custom commands for notation: `\card`, `\hash`, `\ro`, `\expectation`, `\rv`, `\pmf`, `\geodist`
- Algorithm environment using `algorithmicx` package
