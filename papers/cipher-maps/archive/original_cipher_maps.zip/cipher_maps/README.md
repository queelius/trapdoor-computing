# Cipher Maps

[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

A unified theoretical framework bridging **algebraic cipher types**, **Bernoulli approximation models**, and **oblivious data structures** for privacy-preserving computation.

## Abstract

We present cipher maps, a comprehensive theoretical framework unifying oblivious function approximation, algebraic cipher types, and Bernoulli data models. Building on the mathematical foundations of cipher functors that lift monoids into cipher monoids, we develop oblivious Bernoulli maps that provide privacy-preserving function approximation with controllable error rates. These maps satisfy strong obliviousness conditions while maintaining space-optimal implementations.

We introduce the **Singular Hash Map**, achieving `-log₂ε + μ` bits per element asymptotically—matching information-theoretic lower bounds.

## Key Contributions

1. **Unified Mathematical Framework**: Shows how algebraic cipher types induce Bernoulli models, which enable oblivious structures
2. **Information-Theoretic Optimality**: Proves space complexity bounds for oblivious maps with arbitrary-length inputs/outputs
3. **Practical Applications**: Demonstrates applications to differential privacy, secure multi-party computation, and encrypted search

## Building

```bash
# Compile PDF
make

# Clean build artifacts
make clean

# Remove all generated files including PDFs
make cleanall

# Watch for changes and rebuild (requires inotifywait)
make watch
```

## Project Structure

```
cipher_maps/
├── paper/
│   ├── cipher_maps.tex       # Main LaTeX source
│   └── img/                  # TikZ figures
│       ├── fig_shmap.tex
│       └── fig_shs.tex
├── Makefile                  # Build automation
├── README.md                 # This file
├── CLAUDE.md                 # AI assistant guidance
├── CITATION.cff              # GitHub citation metadata
├── zenodo.json               # Zenodo archival metadata
├── LICENSE                   # CC-BY-4.0 license
└── cipher_maps.pdf           # Compiled PDF
```

## Citation

If you use this work, please cite it:

### BibTeX

```bibtex
@article{towell2025ciphermaps,
  title={Cipher Maps: A Unified Framework for Oblivious Function Approximation Through Algebraic Structures and Bernoulli Models},
  author={Towell, Alexander},
  year={2025}
}
```

### Using CITATION.cff

This repository includes a `CITATION.cff` file. On GitHub, click "Cite this repository" in the sidebar for formatted citations.

## Related Work

- [Bernoulli Types](https://github.com/queelius/bernoulli-types-python) - Python implementation of Bernoulli type theory
- [Oblivious Computing](https://github.com/queelius/oblivious-computing) - Parent research monorepo

## License

This work is licensed under [CC-BY-4.0](LICENSE).
